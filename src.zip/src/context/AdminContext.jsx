import { createContext, useContext, useState, useEffect } from 'react'

const STORAGE_KEY = 'carometro_admin'

const AdminContext = createContext({ isAdmin: false, setAdmin: () => {} })

export function AdminProvider({ children }) {
  const [isAdmin, setIsAdmin] = useState(false)

  useEffect(() => {
    setIsAdmin(localStorage.getItem(STORAGE_KEY) === 'true')
  }, [])

  function setAdmin(value) {
    if (value) {
      localStorage.setItem(STORAGE_KEY, 'true')
      setIsAdmin(true)
    } else {
      localStorage.removeItem(STORAGE_KEY)
      setIsAdmin(false)
    }
  }

  return (
    <AdminContext.Provider value={{ isAdmin, setAdmin }}>
      {children}
    </AdminContext.Provider>
  )
}

export function useAdmin() {
  return useContext(AdminContext)
}
