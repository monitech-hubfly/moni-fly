import { useState, useEffect, useMemo } from 'react'
import { supabase } from '../services/supabase'
import { listarAreas } from '../utils/areasOrder'
import PeriodoSelect from '../components/PeriodoSelect'
import { isoWeek } from '../utils/periodos'

export default function Todo() {
  const [periodoId, setPeriodoId] = useState('')
  const [periodoTipo, setPeriodoTipo] = useState(null)
  const [periodo, setPeriodo] = useState(null)
  const [areas, setAreas] = useState([])
  const [ganttList, setGanttList] = useState([])
  const [cronogramaStatus, setCronogramaStatus] = useState({})
  const [filtroArea, setFiltroArea] = useState('')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  async function carregarDados() {
    if (!periodoId) return
    setLoading(true)
    setError(null)

    const { data: p, error: errPer } = await supabase.from('periodos').select('*').eq('id', periodoId).single()
    if (errPer) {
      setError(errPer.message)
      setLoading(false)
      return
    }
    setPeriodo(p)

    const { data: areasData } = await listarAreas(supabase, 'id, nome')
    setAreas(areasData || [])

    let gantt = []
    const { data: ganttData, error: errGantt } = await supabase
      .from('gantt_planejamento')
      .select('id, acao_id, responsavel, semanas_selecionadas, semana_inicio, semana_fim, acoes(nome, tarefas(area_id))')
      .eq('periodo_id', periodoId)
    if (errGantt) {
      setError(errGantt.message)
      setLoading(false)
      return
    }
    gantt = ganttData || []

    const acaoIds = gantt.map(g => g.acao_id).filter(Boolean)
    let cronoByKey = {}
    if (acaoIds.length > 0) {
      const { data: cronoList, error: errCrono } = await supabase
        .from('cronograma')
        .select('acao_id, semana, status')
        .eq('periodo_id', periodoId)
        .in('acao_id', acaoIds)
        .not('semana', 'is', null)
      if (errCrono) {
        setError(errCrono.message)
        setLoading(false)
        return
      }
      ;(cronoList || []).forEach(c => {
        const sem = Number(c.semana)
        if (!Number.isFinite(sem)) return
        cronoByKey[`${c.acao_id}_${sem}`] = c.status || 'pendente'
      })
    }

    setCronogramaStatus(cronoByKey)
    setGanttList(gantt)
    setLoading(false)
  }

  useEffect(() => { carregarDados() }, [periodoId])

  const semanaAtual = useMemo(() => {
    return isoWeek(new Date())
  }, [])

  const areaMap = useMemo(() => {
    const m = new Map()
    ;(areas || []).forEach(a => { m.set(a.id, a.nome) })
    return m
  }, [areas])

  let gruposPlanejadas = []
  let gruposAtraso = []
  try {
    if (periodoId && semanaAtual != null) {
      const byPlanejada = new Map()
      const byAtraso = new Map()

      ;(ganttList || []).forEach(g => {
        const areaId = g.acoes?.tarefas?.area_id
        if (!areaId) return
        if (filtroArea && areaId !== filtroArea) return
        const areaNome = areaMap.get(areaId) || '—'
        const responsavel = g.responsavel || 'Sem responsável'
        const semanasRaw = Array.isArray(g.semanas_selecionadas) && g.semanas_selecionadas.length > 0
          ? g.semanas_selecionadas
          : (g.semana_inicio != null && g.semana_fim != null
            ? Array.from({ length: g.semana_fim - g.semana_inicio + 1 }, (_, i) => g.semana_inicio + i)
            : [])
        ;(semanasRaw || []).forEach(s => {
          const semIso = Number(s)
          if (!Number.isFinite(semIso)) return
          const status = cronogramaStatus[`${g.acao_id}_${semIso}`] || 'pendente'
          if (status === 'concluido') return
          const tipo = semIso < semanaAtual ? 'atraso' : 'planejada'
          const key = `${areaId}__${responsavel}`
          const base = { areaId, areaNome, responsavel, itens: [] }
          const map = tipo === 'planejada' ? byPlanejada : byAtraso
          const grupo = map.get(key) || base
          grupo.itens.push({
            id: `${g.id}_${semIso}`,
            acaoNome: g.acoes?.nome || 'Atividade',
            semana: semIso
          })
          map.set(key, grupo)
        })
      })

      const ordenarGrupos = (a, b) => {
        if (a.areaNome !== b.areaNome) return a.areaNome.localeCompare(b.areaNome)
        return a.responsavel.localeCompare(b.responsavel)
      }
      const ordenarItensPorSemana = (a, b) => a.semana - b.semana

      gruposPlanejadas = Array.from(byPlanejada.values()).sort(ordenarGrupos)
      gruposAtraso = Array.from(byAtraso.values()).sort(ordenarGrupos)
      gruposPlanejadas.forEach(g => { g.itens.sort(ordenarItensPorSemana) })
      gruposAtraso.forEach(g => { g.itens.sort(ordenarItensPorSemana) })
    }
  } catch (e) {
    console.error('Erro ao montar grupos do TO DO', e)
    gruposPlanejadas = []
    gruposAtraso = []
  }

  return (
    <>
      <h1>TO DO — Entregas da semana</h1>
      <p>
        Visão executiva das entregas do plano tático por área e responsável: à esquerda o que está{' '}
        <strong>atrasado</strong>; à direita o que está <strong>planejado</strong> a partir desta semana (ordenado por
        semana), com base no planejamento do Gantt.
      </p>
      {error && <div className="alert alert-error">{error}</div>}

      <div className="page-actions" style={{ flexWrap: 'wrap', gap: '1rem' }}>
        <PeriodoSelect
          value={periodoId}
          defaultTipo={periodoTipo || 'mes'}
          onChange={(id, tipo) => {
            setPeriodoId(id || '')
            setPeriodoTipo(tipo || null)
            setPeriodo(null)
          }}
        />
        <div className="form-group" style={{ marginBottom: 0 }}>
          <label htmlFor="todo-filtro-area">Área</label>
          <select
            id="todo-filtro-area"
            value={filtroArea}
            onChange={e => setFiltroArea(e.target.value)}
            style={{ minWidth: '180px' }}
          >
            <option value="">Todas</option>
            {areas.map(a => (
              <option key={a.id} value={a.id}>
                {a.nome}
              </option>
            ))}
          </select>
        </div>
      </div>

      {loading ? (
        <p>Carregando…</p>
      ) : (
        <div className="todo-linha-dupla">
          <section className="card" style={{ marginTop: 0 }}>
            <h2 style={{ marginTop: 0, marginBottom: '0.5rem' }}>Atrasadas</h2>
            {gruposAtraso.length === 0 ? (
              <p className="empty-state">Nenhuma entrega atrasada no cronograma para o período selecionado.</p>
            ) : (
              <div className="todo-grupos-grid">
                {gruposAtraso.map(grupo => (
                  <div key={`${grupo.areaId}-${grupo.responsavel}-atraso`} className="todo-grupo-card">
                    <div className="todo-grupo-header">
                      <div>
                        <div className="todo-grupo-area">{grupo.areaNome}</div>
                        <div className="todo-grupo-responsavel">{grupo.responsavel}</div>
                      </div>
                      <span className="todo-tag todo-tag-atraso">
                        {grupo.itens.length} tarefa(s)
                      </span>
                    </div>
                    <ul className="todo-lista">
                      {grupo.itens.map(item => (
                        <li key={item.id} className="todo-item">
                          <span className="todo-item-nome">{item.acaoNome}</span>
                          <span className="todo-item-meta">Semana {item.semana}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            )}
          </section>

          <section className="card" style={{ marginTop: 0 }}>
            <h2 style={{ marginTop: 0, marginBottom: '0.5rem' }}>Planejadas</h2>
            {gruposPlanejadas.length === 0 ? (
              <p className="empty-state">
                Nenhuma entrega pendente a partir desta semana no cronograma.
              </p>
            ) : (
              <div className="todo-grupos-grid">
                {gruposPlanejadas.map(grupo => (
                  <div key={`${grupo.areaId}-${grupo.responsavel}-planejada`} className="todo-grupo-card">
                    <div className="todo-grupo-header">
                      <div>
                        <div className="todo-grupo-area">{grupo.areaNome}</div>
                        <div className="todo-grupo-responsavel">{grupo.responsavel}</div>
                      </div>
                      <span className="todo-tag todo-tag-semana">
                        {grupo.itens.length} tarefa(s)
                      </span>
                    </div>
                    <ul className="todo-lista">
                      {grupo.itens.map(item => (
                        <li key={item.id} className="todo-item">
                          <span className="todo-item-nome">{item.acaoNome}</span>
                          <span className="todo-item-meta">Semana {item.semana}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      )}
    </>
  )
}

