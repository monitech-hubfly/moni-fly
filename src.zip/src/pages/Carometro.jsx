/**
 * Carômetro — Scorecard Executivo.
 * Dados: `cronograma` (acao_id → acoes.tarefa_id; semana ISO; periodo_id + status).
 * Engajamento: `gantt_planejamento` — `semanas_selecionadas` (ISO, modelo atual) ou `semana_inicio`/`semana_fim` (internas 1–13, legado).
 * Indicadores: `indicador_lancamentos` por `periodo_id` + `semana` (ISO).
 * Filtro de período: além do UUID selecionado, inclui todos os `periodos` que cruzam o mesmo intervalo de datas
 * (ex.: mês no filtro + trimestre onde o Gantt gravou o `periodo_id`).
 */
import { useState, useEffect, useMemo, useCallback, useRef, Fragment } from 'react'
import { supabase } from '../services/supabase'
import { registrarLog } from '../hooks/useAuditLog'
import { listarAreas } from '../utils/areasOrder'
import { useAdmin } from '../context/AdminContext'
import {
  statusSemaforoPorValor,
  normalizarEntradaCategorica,
  normalizarSemaforo
} from '../utils/semaforoFaixas'
import {
  semanasIsoNoIntervalo,
  labelPeriodo,
  parseSemanaIsoTextoArmazenada,
  isoWeek,
  normalizarSemanasSelecionadasGantt,
  anoIsoParaSemanaNoIntervalo
} from '../utils/periodos'
import SemanaComentarioPillHost from '../components/SemanaComentarioPillHost'

/** Semana ISO (UTC) — alinhado ao pedido v5. */
function getSemanaISOAtual() {
  const hoje = new Date()
  const d = new Date(Date.UTC(hoje.getFullYear(), hoje.getMonth(), hoje.getDate()))
  d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7))
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1))
  return Math.ceil((((d - yearStart) / 86400000 + 1) / 7))
}

/**
 * Datas curtas segunda–domingo da semana ISO (ano civil aproximado para o período).
 */
function getDatasSemanaCurta(semanaISO, ano = new Date().getFullYear()) {
  const simples = new Date(Date.UTC(ano, 0, 1 + (semanaISO - 1) * 7))
  const diaSemana = simples.getUTCDay() || 7
  const segunda = new Date(simples)
  segunda.setUTCDate(simples.getUTCDate() - diaSemana + 1)
  const domingo = new Date(segunda)
  domingo.setUTCDate(segunda.getUTCDate() + 6)
  const fmt = d => `${d.getUTCDate()}/${d.getUTCMonth() + 1}`
  if (segunda.getUTCMonth() !== domingo.getUTCMonth()) {
    return `${fmt(segunda)}–${fmt(domingo)}`
  }
  return `${segunda.getUTCDate()}–${fmt(domingo)}`
}

/**
 * Semanas ISO do intervalo do período selecionado — mesma fonte que o Gantt (`semanasIsoNoIntervalo`).
 * Inteiros ordenados (ex.: [14, 15, 16, 17, 18]).
 */
function calcularSemanasISO(periodoTipo, selecaoId, periodoRow) {
  void periodoTipo
  void selecaoId
  if (!periodoRow?.data_inicio || !periodoRow?.data_fim) return []
  const arr = semanasIsoNoIntervalo(periodoRow.data_inicio, periodoRow.data_fim)
  const nums = arr.map(n => Number(n)).filter(n => Number.isFinite(n))
  return [...new Set(nums)].sort((a, b) => a - b)
}

function semanaEstaNaGrade(w, semanasSet) {
  const n = Number(w)
  if (!Number.isFinite(n)) return false
  if (semanasSet.has(n)) return true
  for (const x of semanasSet) {
    if (Number(x) === n) return true
  }
  return false
}

/** Conclusão no cronograma — valores alternativos ao check constraint legado. */
function statusCronogramaConcluido(status) {
  const x = String(status ?? '')
    .toLowerCase()
    .trim()
  return (
    x === 'concluido' ||
    x === 'concluído' ||
    x === 'realizado' ||
    x === 'feito' ||
    x === 'done' ||
    x === 'completo' ||
    x === 'finalizado'
  )
}

/**
 * Planejado na coluna ISO `sn`: modelo atual = `semanas_selecionadas` (semanas ISO do ano);
 * legado = `semana_inicio`/`semana_fim` internas 1–13 + conversão ISO→interna.
 */
function ganttRowPlanejadoNaSemanaIso(g, semanaIsoNum, semanasGrid, _trimestrePorIdIgnorado, periodoRow) {
  const sn = Number(semanaIsoNum)
  if (!Number.isFinite(sn)) return false

  const ss = normalizarSemanasSelecionadasGantt(g?.semanas_selecionadas)
  if (ss.length > 0) {
    return ss.some(w => Number(w) === sn)
  }

  const si = g.semana_inicio != null ? Number(g.semana_inicio) : NaN
  const sf = g.semana_fim != null ? Number(g.semana_fim) : NaN
  if (!Number.isFinite(si) || !Number.isFinite(sf) || si > sf) return false

  // Legado: quando semana_inicio/fim eram “semana local” do recorte, aproximamos a conversão usando o início do período.
  // Se o banco já grava ISO direto também funciona (local=ISO cai no intervalo).
  let local = sn
  if (periodoRow?.data_inicio) {
    const dataInicio = new Date(`${String(periodoRow.data_inicio).slice(0, 10)}T12:00:00`)
    if (!Number.isNaN(dataInicio.getTime())) {
      const offsetTrimestreIso = isoWeek(dataInicio) - 1
      const interna = sn - offsetTrimestreIso
      // Mantemos um limite amplo (<= 53) para semanas ISO; em bases antigas a “semana local”
      // era 1–13, então interna também cai aqui.
      if (Number.isFinite(interna) && interna >= 1 && interna <= 53) local = interna
    }
  }
  if (local == null) return false
  return si <= local && local <= sf
}

/** Paridade Gantt.buildLancamentosPorIndicadorFromRows / Carômetro legado */
function semanaLancamentoIndicadorParaGrade(row, semanasSet) {
  const arr = Array.from(semanasSet).map(n => Number(n)).filter(n => Number.isFinite(n))
  const gridNums = new Set(arr)
  /** Banco confirmado: `indicador_lancamentos.semana` = ISO do ano (14, 15…) — resolver antes do mapeamento 1–13. */
  if (row.semana != null && row.semana !== '') {
    const sn = Number(row.semana)
    if (Number.isFinite(sn) && gridNums.has(sn)) return sn
  }
  if (row.semana_ano != null && row.semana_ano !== '') {
    const w = parseSemanaIsoTextoArmazenada(row.semana_ano)
    if (w != null && semanaEstaNaGrade(w, semanasSet)) return Number(w)
  }
  const parsed = parseSemanaIsoTextoArmazenada(row.semana)
  if (parsed != null && semanaEstaNaGrade(parsed, semanasSet)) return parsed
  return null
}

/** `cronograma.semana` = ISO no banco confirmado. */
function semanaIsoNaGradeCronograma(cr, semanasGrid) {
  const grid = new Set(semanasGrid.map(n => Number(n)).filter(Number.isFinite))
  if (cr?.semana != null && cr.semana !== '') {
    const sn = Number(cr.semana)
    if (Number.isFinite(sn) && grid.has(sn)) return sn
  }
  return null
}

/**
 * Engajamento de um comportamento numa semana ISO: concluídas / ações com planejamento Gantt naquela semana.
 * Sem planejamento na semana, ou semana atual/futura → null. Semana passada → % (inclui 0%).
 */
function calcularEngajamentoSemana(
  tarefaId,
  semanaISO,
  semanaAtual,
  acoesRows,
  cronogramaList,
  ganttPlanejamento,
  semanasGrid,
  periodoRow
) {
  const sn = Number(semanaISO)
  const sa = Number(semanaAtual)
  if (!Number.isFinite(sn) || !Number.isFinite(sa)) return null
  const acoesDaTarefa = acoesRows.filter(a => a.tarefa_id === tarefaId)
  if (acoesDaTarefa.length === 0) return null

  const acoesPlanejadasNaSemana = acoesDaTarefa.filter(acao =>
    (ganttPlanejamento || []).some(g =>
      g.acao_id === acao.id && ganttRowPlanejadoNaSemanaIso(g, sn, semanasGrid, null, periodoRow)
    )
  )
  if (acoesPlanejadasNaSemana.length === 0) return null
  if (sn >= sa) return null

  const ids = new Set(acoesPlanejadasNaSemana.map(a => a.id))
  let concluidas = 0
  for (const c of cronogramaList || []) {
    if (!ids.has(c.acao_id)) continue
    const w = semanaIsoNaGradeCronograma(c, semanasGrid)
    if (w == null || Number(w) !== sn) continue
    if (statusCronogramaConcluido(c.status)) concluidas++
  }
  return Math.round((concluidas / acoesPlanejadasNaSemana.length) * 100)
}

/**
 * Engajamento no período (só semanas passadas): soma concluídas / soma de “ações planejadas × semana”.
 */
function calcularEngajamentoPeriodo(
  tarefaId,
  semanasNoPeriodo,
  semanaAtual,
  acoesRows,
  cronogramaList,
  ganttPlanejamento,
  semanasGrid,
  periodoRow
) {
  const acoesDaTarefa = acoesRows.filter(a => a.tarefa_id === tarefaId)
  if (acoesDaTarefa.length === 0) return null
  const sa = Number(semanaAtual)
  const semanasPasadas = (semanasNoPeriodo || []).map(Number).filter(w => Number.isFinite(w) && w < sa)
  if (semanasPasadas.length === 0) return null

  let totalPlanejadas = 0
  let totalConcluidas = 0
  for (const semana of semanasPasadas) {
    const sn = Number(semana)
    const acoesPlanejadasNaSemana = acoesDaTarefa.filter(acao =>
      (ganttPlanejamento || []).some(g =>
        g.acao_id === acao.id && ganttRowPlanejadoNaSemanaIso(g, sn, semanasGrid, null, periodoRow)
      )
    )
    totalPlanejadas += acoesPlanejadasNaSemana.length
    if (acoesPlanejadasNaSemana.length === 0) continue
    const ids = new Set(acoesPlanejadasNaSemana.map(a => a.id))
    for (const c of cronogramaList || []) {
      if (!ids.has(c.acao_id)) continue
      const w = semanaIsoNaGradeCronograma(c, semanasGrid)
      if (w == null || Number(w) !== sn) continue
      if (statusCronogramaConcluido(c.status)) totalConcluidas++
    }
  }
  if (totalPlanejadas === 0) return null
  return Math.round((totalConcluidas / totalPlanejadas) * 100)
}

function mergeLancRows(base, extra) {
  const key = r => `${r.indicador_id}|${r.semana}|${String(r.periodo_id ?? '')}`
  const byKey = new Map((base || []).filter(Boolean).map(r => [key(r), r]))
  ;(extra || []).forEach(r => {
    if (r && !byKey.has(key(r))) byKey.set(key(r), r)
  })
  return Array.from(byKey.values())
}

/** PostgREST: coluna ausente / schema cache — tentar próximo SELECT reduzido. */
function erroColunaOuSchemaSupabase(err) {
  const m = String(err?.message ?? err ?? '').toLowerCase()
  if (!m) return false
  return (
    m.includes('does not exist') ||
    m.includes('column') ||
    m.includes('schema cache') ||
    m.includes('could not find') ||
    m.includes('pgrst')
  )
}

/**
 * Cadeia do banco: areas → objetivos → tarefas (comportamentos) → acoes → cronograma.
 * `tarefas`: apenas colunas confirmadas. Chave = `acoes.caneta_verde`.
 */
async function selectTarefasCarometro(supabase, objIds, areaIds) {
  const sel = 'id, nome, objetivo_id, area_id'
  const r1 = await supabase.from('tarefas').select(sel).in('objetivo_id', objIds)
  if (r1.error) return { error: r1.error, sel }

  let tarefasSoArea = []
  if ((areaIds || []).length > 0) {
    const r2 = await supabase.from('tarefas').select(sel).in('area_id', areaIds).is('objetivo_id', null)
    if (r2.error) return { error: r2.error, sel }
    tarefasSoArea = r2.data || []
  }

  return {
    tCom: r1.data || [],
    tarefasSoArea,
    sel,
    flags: { hasResponsavelCol: false }
  }
}

function comportamentoEhChavePorCaneta(acoesDaTarefa) {
  return (acoesDaTarefa || []).some(a => String(a?.caneta_verde ?? '').toLowerCase() === 'sim')
}

/** statusSemaforoPorValor → ive | ivc | iam | ivm | ina */
function mapSemaforoParaCar(st) {
  if (st == null) return 'ina'
  const m = { ve: 'ive', vc: 'ivc', am: 'iam', vm: 'ivm' }
  return m[st] || 'ina'
}

/**
 * Semáforo por célula no Carômetro: regras cadastradas + qualitativo OK/Andamento/Não OK → cores da legenda.
 * Andamento → ivc (Atingiu), não iam — alinhado à aba Indicadores.
 */
function statusCarometroIndicadorCelula(ind, valor) {
  if (valor == null || String(valor).trim() === '') return 'ina'

  const tipoDb = String(ind?.tipo ?? '').toLowerCase()
  const uni = String(ind?.unidade ?? '')
  const escala = normalizarSemaforo(ind).escala_tipo
  const qualExplicito =
    tipoDb === 'qualitativo' || (uni.includes('OK') && uni.includes('Andamento')) || escala === 'status_3'

  if (qualExplicito) {
    const vNorm = normalizarEntradaCategorica(valor, 'status_3')
    if (vNorm) {
      if (vNorm === 'OK') return 'ive'
      if (vNorm === 'ANDAMENTO') return 'ivc'
      if (vNorm === 'NAO_OK') return 'ivm'
      return 'ivm'
    }
  }

  const st = statusSemaforoPorValor(ind, valor)
  return mapSemaforoParaCar(st)
}

/** Badges semáforo — faixas de % (UI scorecard; alinhado à legenda) */
const BADGE_COMPORT_SOLID = {
  e100: { background: '#2e7d32', color: '#fff' },
  e75: { background: '#8bc34a', color: '#fff' },
  e50: { background: '#e6a817', color: '#fff' },
  elow: { background: '#e74c3c', color: '#fff' }
}

const BADGE_IND_SOLID = {
  ive: { background: '#2e7d32', color: '#fff' },
  ivc: { background: '#8bc34a', color: '#fff' },
  iam: { background: '#e6a817', color: '#fff' },
  ivm: { background: '#e74c3c', color: '#fff' }
}

/** Cor do badge pela % (coluna Status e células com número) */
function estiloBadgePctSolido(pct) {
  if (pct == null || Number.isNaN(pct)) return null
  if (pct >= 75) return { background: '#2e7d32', color: '#fff' }
  if (pct >= 60) return { background: '#8bc34a', color: '#fff' }
  if (pct >= 30) return { background: '#e6a817', color: '#fff' }
  return { background: '#e74c3c', color: '#fff' }
}

/** Arquivos em public/image/ — respeita `import.meta.env.BASE_URL` (ex.: deploy em subpasta). */
function publicImageUrl(fileName) {
  const base = import.meta.env.BASE_URL || '/'
  const prefix = base.endsWith('/') ? base : `${base}/`
  return `${prefix}image/${fileName}`.replace(/\/{2,}/g, '/')
}

/** Mapeia código de semáforo da grade (ive|ivc|iam|ivm|ina) → PNG em public/image/. */
function getCarinhaPathPorCodigoInd(cod) {
  switch (cod) {
    case 'ive':
      return publicImageUrl('Dark_Green.png')
    case 'ivc':
      return publicImageUrl('Green.png')
    case 'iam':
      return publicImageUrl('Yellow.png')
    case 'ivm':
      return publicImageUrl('Red.png')
    case 'ina':
    default:
      return publicImageUrl('White.png')
  }
}

function getLabelPorCodigoInd(cod) {
  switch (cod) {
    case 'ive':
      return '≥75% · Ótimo'
    case 'ivc':
      return '60–74% · Bom'
    case 'iam':
      return '30–59% · Atenção'
    case 'ivm':
      return '< 30% · Crítico'
    case 'ina':
    default:
      return 'Sem dado'
  }
}

/** Mapeia código de esforço da grade (e100|e75|e50|elow|ena) → PNG em public/image/. */
function getCarinhaPathPorCodigoComp(cod) {
  switch (cod) {
    case 'e100':
      return publicImageUrl('Dark_Green.png')
    case 'e75':
      return publicImageUrl('Green.png')
    case 'e50':
      return publicImageUrl('Yellow.png')
    case 'elow':
      return publicImageUrl('Red.png')
    case 'ena':
    default:
      return publicImageUrl('White.png')
  }
}

function getLabelPorCodigoComp(cod) {
  switch (cod) {
    case 'e100':
      return '≥75% · Ótimo'
    case 'e75':
      return '60–74% · Bom'
    case 'e50':
      return '30–59% · Atenção'
    case 'elow':
      return '< 30% · Crítico'
    case 'ena':
    default:
      return 'Sem dado'
  }
}

function getBackgroundPosition(carinhaPath) {
  const p = String(carinhaPath ?? '')
  if (p.includes('Dark_Green')) return 'center 10%'
  if (p.includes('Green')) return 'center 15%'
  if (p.includes('Yellow')) return 'center 15%'
  if (p.includes('Red')) return 'center 20%'
  if (p.includes('White')) return 'center 15%'
  return 'center 15%'
}

function CarinhaBlocoResumo({ tipo, codigo, labelColor, imgAlt = 'carinha', carinhaVisible }) {
  const carinhaPath =
    tipo === 'ind' ? getCarinhaPathPorCodigoInd(codigo) : getCarinhaPathPorCodigoComp(codigo)
  const label = tipo === 'ind' ? getLabelPorCodigoInd(codigo) : getLabelPorCodigoComp(codigo)
  const estiloCirculoCarinha = carinhaVisible
    ? {
        width: 110,
        height: 110,
        borderRadius: '50%',
        backgroundImage: `url(${carinhaPath})`,
        backgroundSize: '180%',
        backgroundPosition: getBackgroundPosition(carinhaPath),
        backgroundRepeat: 'no-repeat',
        flexShrink: 0,
        overflow: 'hidden'
      }
    : {
        width: 110,
        height: 110,
        borderRadius: '50%',
        flexShrink: 0,
        overflow: 'hidden'
      }
  return (
    <div
      style={{
        flexShrink: 0,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 6,
        width: 120
      }}
    >
      {carinhaVisible ? (
        <div style={estiloCirculoCarinha} role="img" aria-label={imgAlt} />
      ) : (
        <div style={estiloCirculoCarinha} aria-hidden />
      )}
      <span style={{ fontSize: 10, fontWeight: 500, textAlign: 'center', color: labelColor }}>
        {label}
      </span>
    </div>
  )
}

function SemBadge({ children, variant, empty, style }) {
  const cls = ['sem-badge']
  if (variant === 'cell') cls.push('sem-badge--cell')
  if (variant === 'status') cls.push('sem-badge--status')
  if (variant === 'legend') cls.push('sem-badge--legend')
  if (empty) cls.push('sem-badge--empty')
  return (
    <span className={cls.join(' ')} style={empty ? undefined : style}>
      {children}
    </span>
  )
}

/** Cor de texto, barra e faixa descritiva a partir do % (cards resumo). */
function getCorPorcentagem(pct) {
  if (pct === null || pct === undefined || Number.isNaN(pct)) {
    return { cor: '#888780', barCor: '#C0BDB4', label: 'Sem dado' }
  }
  if (pct >= 75) return { cor: '#1b5e20', barCor: '#2e7d32', label: '≥75% · Ótimo' }
  if (pct >= 60) return { cor: '#1b5e20', barCor: '#8bc34a', label: '60–74% · Bom' }
  if (pct >= 30) return { cor: '#e6a817', barCor: '#e6a817', label: '30–59% · Atenção' }
  return { cor: '#b71c1c', barCor: '#e74c3c', label: '<30% · Crítico' }
}

/** Cor do texto do label da carinha (resultado médio do mês) — cards de resumo. */
function corLabelFaixaResultadoMedioMes(pct) {
  if (pct === null || pct === undefined || Number.isNaN(pct)) return 'var(--color-text-secondary)'
  if (pct >= 75) return '#1b5e20'
  if (pct >= 60) return '#33691e'
  if (pct >= 30) return '#e6a817'
  return '#b71c1c'
}

/** Valores grandes — card Engajamento (faixas). */
function corValorGrandeEngajamento(pct) {
  if (pct === null || pct === undefined || Number.isNaN(pct)) return 'var(--color-text-secondary)'
  if (pct >= 75) return '#1b5e20'
  if (pct >= 60) return '#33691e'
  if (pct >= 30) return '#e6a817'
  return '#b71c1c'
}

function corBarraFaixa(pct) {
  if (pct === null || pct === undefined || Number.isNaN(pct)) return 'var(--color-border-tertiary)'
  if (pct >= 75) return '#2e7d32'
  if (pct >= 60) return '#8bc34a'
  if (pct >= 30) return '#e6a817'
  return '#e74c3c'
}

function BarraProgresso({ pct }) {
  const p = pct != null && !Number.isNaN(pct) ? Number(pct) : null
  const tem = p != null
  const fill = corBarraFaixa(pct)
  const w = tem ? Math.min(100, Math.max(0, p)) : 0
  return (
    <div
      style={{
        height: 3,
        borderRadius: 2,
        width: '80%',
        margin: '4px auto 0',
        overflow: 'hidden',
        background: '#e0e0e0'
      }}
    >
      <div
        style={{
          height: '100%',
          borderRadius: 2,
          width: tem ? `${w}%` : '100%',
          background: tem ? fill : 'var(--color-border-tertiary)'
        }}
      />
    </div>
  )
}

function CelulaSemanaComportamento({ cod, pct, comentarioTooltip }) {
  const p = pct != null && !Number.isNaN(pct) ? Math.round(pct) : null
  const wrap = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '4px 2px'
  }
  const tip = comentarioTooltip != null ? String(comentarioTooltip).trim() : ''
  const dotsPlan = cod === 'ena' || p == null
  if (cod === 'ena' || p == null) {
    const badge = (
      <span style={{ position: 'relative', display: 'inline-block' }}>
        <SemBadge variant="cell" empty>
          —
        </SemBadge>
        {tip ? (
          <span className={`gantt-comentario-dots${dotsPlan ? ' gantt-comentario-dots--plan' : ''}`} aria-hidden>
            ···
          </span>
        ) : null}
      </span>
    )
    return (
      <div style={wrap}>
        {tip ? <SemanaComentarioPillHost tooltipText={tip}>{badge}</SemanaComentarioPillHost> : badge}
      </div>
    )
  }
  const st = BADGE_COMPORT_SOLID[cod] || BADGE_COMPORT_SOLID.elow
  const badge = (
    <SemBadge
      variant="cell"
      style={{ ...st, position: tip ? 'relative' : undefined, display: tip ? 'inline-block' : undefined }}
    >
      {p}%
      {tip ? (
        <span className={`gantt-comentario-dots${dotsPlan ? ' gantt-comentario-dots--plan' : ''}`} aria-hidden>
          ···
        </span>
      ) : null}
    </SemBadge>
  )
  return (
    <div style={wrap}>
      {tip ? <SemanaComentarioPillHost tooltipText={tip}>{badge}</SemanaComentarioPillHost> : badge}
    </div>
  )
}

function PillStatusComportamento({ cod, pctMedia }) {
  void cod
  const pct =
    pctMedia != null && !Number.isNaN(pctMedia) ? Math.round(Number(pctMedia)) : null
  if (pct == null) {
    return (
      <SemBadge variant="status" empty>
        —
      </SemBadge>
    )
  }
  const st = estiloBadgePctSolido(pct)
  return <SemBadge variant="status" style={st}>{pct}%</SemBadge>
}

function PillStatusIndicador({ cod, pctMedia }) {
  void cod
  const pct =
    pctMedia != null && !Number.isNaN(pctMedia) ? Math.round(Number(pctMedia)) : null
  if (pct == null) {
    return (
      <SemBadge variant="status" empty>
        —
      </SemBadge>
    )
  }
  const st = estiloBadgePctSolido(pct)
  return <SemBadge variant="status" style={st}>{pct}%</SemBadge>
}

function CelulaIndicadorSemana({ cod, valor, comentarioTooltip }) {
  const raw = valor != null ? String(valor).trim() : ''
  const n = Number(raw.replace(',', '.'))
  const showNum = raw !== '' && !Number.isNaN(n) && Number.isFinite(n) && cod !== 'ina'
  const indLabels = { ive: 'Superou', ivc: 'Atingiu', iam: 'Abaixo', ivm: 'Crítico', ina: '—' }
  const wrap = {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '4px 2px'
  }
  const tip = comentarioTooltip != null ? String(comentarioTooltip).trim() : ''
  const dotsPlan = cod === 'ina'
  if (cod === 'ina') {
    const badge = (
      <span style={{ position: 'relative', display: 'inline-block' }}>
        <SemBadge variant="cell" empty>
          —
        </SemBadge>
        {tip ? (
          <span className={`gantt-comentario-dots${dotsPlan ? ' gantt-comentario-dots--plan' : ''}`} aria-hidden>
            ···
          </span>
        ) : null}
      </span>
    )
    return (
      <div style={wrap}>
        {tip ? <SemanaComentarioPillHost tooltipText={tip}>{badge}</SemanaComentarioPillHost> : badge}
      </div>
    )
  }
  const st = BADGE_IND_SOLID[cod] || BADGE_IND_SOLID.ivm
  let content = indLabels[cod] ?? '—'
  if (showNum) content = raw
  else if (raw !== '') content = raw
  const badge = (
    <SemBadge
      variant="cell"
      style={{ ...st, position: tip ? 'relative' : undefined, display: tip ? 'inline-block' : undefined }}
    >
      {content}
      {tip ? (
        <span className={`gantt-comentario-dots${dotsPlan ? ' gantt-comentario-dots--plan' : ''}`} aria-hidden>
          ···
        </span>
      ) : null}
    </SemBadge>
  )
  return (
    <div style={wrap}>
      {tip ? <SemanaComentarioPillHost tooltipText={tip}>{badge}</SemanaComentarioPillHost> : badge}
    </div>
  )
}

/** Paridade Gantt.jsx — uuid de meta pode divergir por string vs objeto. */
function idObjetivoIgual(a, b) {
  if (a == null || b == null) return false
  return String(a).replace(/-/g, '').toLowerCase() === String(b).replace(/-/g, '').toLowerCase()
}

function metaIdCanonica(metas, oid) {
  if (oid == null) return oid
  const found = (metas || []).find(m => idObjetivoIgual(m.id, oid))
  return found?.id ?? oid
}

function primeiroObjetivoDaArea(objetivos, areaId) {
  if (!areaId) return null
  const list = (objetivos || []).filter(o => o.area_id === areaId)
  list.sort((a, b) => (Number(a.ordem) || 0) - (Number(b.ordem) || 0))
  return list[0] || null
}

/** Gantt carrega tarefas por área; comportamentos sem `objetivo_id` herdam a primeira meta da mesma área. */
function mesclarComportamentosComMetas(objetivos, tarefasComObjetivo, tarefasSoArea) {
  const byId = new Map()
  for (const t of tarefasComObjetivo || []) byId.set(t.id, { ...t })
  for (const t of tarefasSoArea || []) {
    if (byId.has(t.id)) continue
    const meta = primeiroObjetivoDaArea(objetivos, t.area_id)
    if (!meta) continue
    byId.set(t.id, { ...t, objetivo_id: meta.id })
  }
  return Array.from(byId.values())
}

/** Gantt carrega indicadores por `area_id` e redistribui às metas; mesma lógica aqui. */
function mesclarIndicadoresNasMetas(objetivos, indicadoresPorArea) {
  const objIdSet = new Set((objetivos || []).map(o => o.id).filter(Boolean))
  const out = []
  for (const ind of indicadoresPorArea || []) {
    const canon = metaIdCanonica(objetivos, ind.objetivo_id)
    if (canon && objIdSet.has(canon)) {
      out.push({ ...ind, objetivo_id: canon })
      continue
    }
    const meta = primeiroObjetivoDaArea(objetivos, ind.area_id)
    if (meta) out.push({ ...ind, objetivo_id: meta.id })
  }
  return out
}

/** Ordenação estável quando não há id/criado_em no select (schema mínimo). */
function ordenarLancamentosIndicadorParaGradeCar(rows) {
  if (!rows?.length) return rows
  return [...rows]
}

/** Prazo na UI: no banco não há coluna `prazo`; o app grava a semana-alvo em `meta_unidade` como "S13". */
function prazoExibicaoObjetivo(meta) {
  const u = String(meta?.meta_unidade ?? '').trim()
  if (/^S\d+$/i.test(u)) return u.replace(/^s/i, 'S')
  return null
}

/**
 * Monta árvore área → metas → comportamentos / indicadores com cores por semana.
 * esforco: tarefaId → { [semanaISO]: código }; esforcoPct: mesmo id → % numérico ou null
 */
function agruparPorAreaEMeta({
  areas,
  objetivos,
  tarefas,
  indicadores,
  esforco,
  esforcoPct,
  pctPeriodoPorComportamento,
  semaf,
  indValorPorSemana,
  semanas,
  visualizacao
}) {
  const objByArea = new Map()
  for (const o of objetivos || []) {
    if (!o?.area_id) continue
    if (!objByArea.has(o.area_id)) objByArea.set(o.area_id, [])
    objByArea.get(o.area_id).push(o)
  }

  const tarefasPorObj = new Map()
  for (const t of tarefas || []) {
    const oid = metaIdCanonica(objetivos, t.objetivo_id)
    if (!oid) continue
    if (!tarefasPorObj.has(oid)) tarefasPorObj.set(oid, [])
    tarefasPorObj.get(oid).push(t)
  }

  const indPorObj = new Map()
  for (const ind of indicadores || []) {
    const oid = metaIdCanonica(objetivos, ind.objetivo_id)
    if (!oid) continue
    if (!indPorObj.has(oid)) indPorObj.set(oid, [])
    indPorObj.get(oid).push(ind)
  }

  const out = []
  for (const area of areas || []) {
    const metasRaw = objByArea.get(area.id) || []
    const metas = []
    for (const meta of metasRaw) {
      let comps = (tarefasPorObj.get(meta.id) || []).map(t => ({
        id: t.id,
        nome: t.nome || t.descricao || '—',
        responsavel: (t.responsavel && String(t.responsavel).trim()) ? String(t.responsavel).trim() : '—',
        isChave: !!t.isChave,
        semanas: {},
        pctSemanas: {},
        pctPeriodo: pctPeriodoPorComportamento?.[t.id] ?? null
      }))
      let inds = (indPorObj.get(meta.id) || []).map(i => ({
        id: i.id,
        nome: i.nome || '—',
        tipo: i.tipo || null,
        indicador_chave: !!i.indicador_chave,
        isChave: !!i.indicador_chave,
        semanas: {},
        valorSemanas: {}
      }))

      for (const c of comps) {
        for (const w of semanas) {
          const wn = Number(w)
          c.semanas[wn] = esforco[c.id]?.[wn] ?? esforco[c.id]?.[w] ?? 'ena'
          c.pctSemanas[wn] = esforcoPct?.[c.id]?.[wn] ?? esforcoPct?.[c.id]?.[w] ?? null
        }
      }
      for (const ind of inds) {
        for (const w of semanas) {
          const wn = Number(w)
          ind.semanas[wn] = semaf[ind.id]?.[wn] ?? semaf[ind.id]?.[w] ?? 'ina'
          ind.valorSemanas[wn] = indValorPorSemana?.[ind.id]?.[wn] ?? indValorPorSemana?.[ind.id]?.[w] ?? null
        }
      }

      if (visualizacao === 'chave') {
        comps = comps.filter(c => c.isChave)
        inds = inds.filter(i => i.isChave)
      }
      if (comps.length === 0 && inds.length === 0) continue

      metas.push({
        id: meta.id,
        descricao: meta.descricao || '—',
        prazo: prazoExibicaoObjetivo(meta),
        comportamentos: comps,
        indicadores: inds
      })
    }
    if (metas.length === 0) continue
    out.push({ area: { id: area.id, nome: area.nome || '—' }, metas })
  }
  return out
}

/** Média dos % nas semanas com dado (comportamento — coluna Status). */
function mediaPctComportamento(pctSemanas, semanasOrder) {
  const vals = semanasOrder.map(wn => pctSemanas[Number(wn)]).filter(v => v != null && !Number.isNaN(v))
  if (!vals.length) return null
  return vals.reduce((a, b) => a + b, 0) / vals.length
}

/** Média dos % convertidos do semáforo nas semanas com dado (indicador). */
function mediaPctIndicador(semanasCod, semanasOrder) {
  const scMap = { ive: 100, ivc: 67, iam: 45, ivm: 15 }
  const vals = semanasOrder
    .map(wn => semanasCod[Number(wn)])
    .filter(c => c && c !== 'ina' && scMap[c] != null)
    .map(c => scMap[c])
  if (!vals.length) return null
  return vals.reduce((a, b) => a + b, 0) / vals.length
}

function statusConsolidadoComportamento(pctSemanas, semanasOrder, pctPeriodo) {
  const avg =
    pctPeriodo != null && !Number.isNaN(pctPeriodo)
      ? pctPeriodo
      : mediaPctComportamento(pctSemanas, semanasOrder)
  if (avg == null) return 'ena'
  if (avg >= 75) return 'e100'
  if (avg >= 60) return 'e75'
  if (avg >= 30) return 'e50'
  return 'elow'
}

/** Última semana com lançamento no período (indicador — coluna Status). */
function statusUltimoIndicador(semanasCod, semanasOrder) {
  for (let i = semanasOrder.length - 1; i >= 0; i--) {
    const wn = Number(semanasOrder[i])
    const c = semanasCod[wn]
    if (c && c !== 'ina') return c
  }
  return 'ina'
}

/** Carinha alinhada ao % de "Resultado médio" do card (mesmo número exibido no período). */
function calcularCodigoPorResultadoMedio(valor) {
  const n = parseFloat(valor)
  if (
    valor === null ||
    valor === undefined ||
    valor === '—' ||
    valor === '' ||
    Number.isNaN(n)
  ) {
    return 'ina'
  }
  if (n >= 75) return 'ive'
  if (n >= 60) return 'ivc'
  if (n >= 30) return 'iam'
  return 'ivm'
}

/** Mesmas faixas que calcularCodigoPorResultadoMedio → códigos da grade de comportamento (e100…). */
function bandPctParaCodigoComportamento(codInd) {
  const map = { ive: 'e100', ivc: 'e75', iam: 'e50', ivm: 'elow', ina: 'ena' }
  return map[codInd] ?? 'ena'
}

export default function Carometro() {
  const { isAdmin } = useAdmin()

  const [periodo, setPeriodo] = useState('mes')
  const [selecao, setSelecao] = useState('')
  const [selecaoMultipla, setSelecaoMultipla] = useState([])
  const [opcoesPeriodo, setOpcoesPeriodo] = useState([])
  const [opcoesPeriodoDraft, setOpcoesPeriodoDraft] = useState([])
  /** Linha `periodos` vinda do Supabase por UUID — não derivar só de `opcoesPeriodo` (evita datas ausentes no cálculo de semanas). */
  const [periodoDb, setPeriodoDb] = useState(null)
  const [areaSelecionada, setAreaSelecionada] = useState('geral')
  const [areasMultiplas, setAreasMultiplas] = useState(['geral'])
  const [visualizacao, setVisualizacao] = useState('geral')
  const [areas, setAreas] = useState([])
  const [dados, setDados] = useState([])
  /** Semanas ISO que aparecem no `cronograma` carregado — para semana de referência dos cards. */
  const [semanasIsoComLancamentoCronograma, setSemanasIsoComLancamentoCronograma] = useState([])
  const [comentariosAtividadeRows, setComentariosAtividadeRows] = useState([])
  const [comentariosIndicadorRows, setComentariosIndicadorRows] = useState([])
  const [acaoIdsPorTarefaCarometro, setAcaoIdsPorTarefaCarometro] = useState({})
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [salvandoChave, setSalvandoChave] = useState(null)
  /** `responsavel` opcional em `tarefas`. Chave do comportamento: `acoes.caneta_verde` (não coluna em tarefas). */
  const [schemaTarefasCar, setSchemaTarefasCar] = useState({ responsavelCol: false })
  const semanasMemo = useMemo(() => {
    if (!periodoDb?.data_inicio || !periodoDb?.data_fim) {
      return []
    }
    return calcularSemanasISO(periodo, selecao, periodoDb)
  }, [periodoDb, periodo, selecao])
  const semanasKey = useMemo(() => semanasMemo.join(','), [semanasMemo])

  /** Exibição: ordenação numérica crescente (S14, S15, …). */
  const semanasOrdenadas = useMemo(
    () => [...semanasMemo].sort((a, b) => Number(a) - Number(b)),
    [semanasMemo]
  )

  /** Até 5 semanas terminando na semana ISO atual (última coluna = semana corrente quando existir no período). */
  const semanasVisiveis = useMemo(() => {
    const ord = semanasOrdenadas
    if (ord.length === 0) return []
    const wHoje = getSemanaISOAtual()
    const idx = ord.indexOf(wHoje)
    if (idx >= 0) {
      const start = Math.max(0, idx - 4)
      return ord.slice(start, idx + 1)
    }
    return ord.slice(0, 5)
  }, [semanasOrdenadas])

  /** Coluna destacada: última semana visível (= atual quando a atual está no período). */
  const semanaColunaDestaque = useMemo(
    () => (semanasVisiveis.length ? semanasVisiveis[semanasVisiveis.length - 1] : null),
    [semanasVisiveis]
  )

  const anoDatasSemana = periodoDb?.ano != null ? Number(periodoDb.ano) : new Date().getFullYear()

  const textoComentarioComportamentoCar = useMemo(() => {
    const merged = new Map()
    for (const r of comentariosAtividadeRows || []) {
      if (!r?.acao_id) continue
      const k = `${r.acao_id}|${r.semana_iso}|${r.semana_ano}`
      const t = String(r.texto || '').trim()
      if (!t) continue
      merged.set(k, merged.has(k) ? `${merged.get(k)} — ${t}` : t)
    }
    return (tarefaId, w) => {
      const wn = Number(w)
      const ano = anoIsoParaSemanaNoIntervalo(wn, periodoDb?.data_inicio, periodoDb?.data_fim)
      const aids = acaoIdsPorTarefaCarometro[tarefaId] || []
      const parts = []
      for (const aid of aids) {
        const x = merged.get(`${aid}|${wn}|${ano}`)
        if (x) parts.push(x)
      }
      return parts.length ? parts.join(' — ') : null
    }
  }, [comentariosAtividadeRows, acaoIdsPorTarefaCarometro, periodoDb?.data_inicio, periodoDb?.data_fim])

  const textoComentarioIndicadorCar = useMemo(() => {
    const merged = new Map()
    for (const r of comentariosIndicadorRows || []) {
      if (!r?.indicador_id) continue
      const k = `${r.indicador_id}|${r.semana_iso}|${r.semana_ano}`
      const t = String(r.texto || '').trim()
      if (!t) continue
      merged.set(k, merged.has(k) ? `${merged.get(k)} — ${t}` : t)
    }
    return (indicadorId, w) => {
      const wn = Number(w)
      const ano = anoIsoParaSemanaNoIntervalo(wn, periodoDb?.data_inicio, periodoDb?.data_fim)
      return merged.get(`${indicadorId}|${wn}|${ano}`) || null
    }
  }, [comentariosIndicadorRows, periodoDb?.data_inicio, periodoDb?.data_fim])

  const depsFetch = useRef('')

  useEffect(() => {
    let cancel = false
    async function loadOpcoes() {
      const { data, error: e } = await supabase
        .from('periodos')
        .select('*')
        .eq('tipo', periodo)
        .order('ano', { ascending: false })
        .order('numero', { ascending: false })
      if (cancel) return
      if (e) {
        setOpcoesPeriodo([])
        return
      }
      setOpcoesPeriodo(data || [])
      setOpcoesPeriodoDraft(data || [])
      if (data?.length) {
        const now = new Date()
        const prefer =
          periodo === 'mes'
            ? data.find(
                p => Number(p.ano) === now.getFullYear() && Number(p.numero) === now.getMonth() + 1
              )
            : null
        const fallback = prefer?.id || data[0].id
        setSelecao(prev => {
          if (prev && data.some(p => p.id === prev)) return prev
          return fallback
        })
        setSelecaoMultipla(prev => {
          const validPrev = (prev || []).filter(x => data.some(p => p.id === x))
          if (validPrev.length) return validPrev
          return fallback ? [fallback] : []
        })
      }
    }
    loadOpcoes()
    return () => {
      cancel = true
    }
  }, [periodo])

  useEffect(() => {
    if (!selecao && opcoesPeriodo.length > 0) {
      setSelecao(opcoesPeriodo[0].id)
    }
  }, [opcoesPeriodo, selecao])

  useEffect(() => {
    const first = (selecaoMultipla || [])[0] || ''
    if (first && first !== selecao) setSelecao(first)
    if (!first && selecao) setSelecao('')
  }, [selecaoMultipla])

  useEffect(() => {
    let cancel = false
    async function loadPeriodoDbRow() {
      if (!selecao) {
        setPeriodoDb(null)
        return
      }
      const { data: periodoData, error: periodoErr } = await supabase
        .from('periodos')
        .select('id, data_inicio, data_fim, tipo, ano, numero')
        .eq('id', selecao)
        .single()
      if (cancel) return
      if (periodoErr || !periodoData) {
        setPeriodoDb(null)
        return
      }
      setPeriodoDb(periodoData)
    }
    loadPeriodoDbRow()
    return () => {
      cancel = true
    }
  }, [selecao])

  const carregarDados = useCallback(async () => {
    const key = JSON.stringify({
      selecao,
      areaSelecionada,
      semLen: semanasMemo.length,
      v: visualizacao
    })
    if (!selecao || !periodoDb?.data_inicio || !periodoDb?.data_fim || semanasMemo.length === 0) {
      setDados([])
      setSemanasIsoComLancamentoCronograma([])
      setComentariosAtividadeRows([])
      setComentariosIndicadorRows([])
      setAcaoIdsPorTarefaCarometro({})
      setLoading(false)
      return
    }
    depsFetch.current = key
    setLoading(true)
    setError(null)

    try {
      const { data: areasData } = await listarAreas(supabase, 'id, nome')
      setAreas(areasData || [])
      void (
        areaSelecionada !== 'geral'
          ? (areasData || []).find(a => a.id === areaSelecionada)
          : null
      )

      let qObj = supabase
        .from('objetivos')
        .select('id, descricao, area_id, ordem, meta_unidade, periodo_id')
        .eq('status', 'ativo')
      if (areaSelecionada !== 'geral') qObj = qObj.eq('area_id', areaSelecionada)
      let { data: objetivos, error: errObj } = await qObj
      if (errObj && String(errObj.message || '').toLowerCase().includes('status')) {
        let q2 = supabase
          .from('objetivos')
          .select('id, descricao, area_id, ordem, meta_unidade, periodo_id')
        if (areaSelecionada !== 'geral') q2 = q2.eq('area_id', areaSelecionada)
        const r2 = await q2
        objetivos = r2.data
        errObj = r2.error
      }
      if (errObj) {
        setError(errObj.message)
        setDados([])
        setSemanasIsoComLancamentoCronograma([])
        setComentariosAtividadeRows([])
        setComentariosIndicadorRows([])
        setAcaoIdsPorTarefaCarometro({})
        setLoading(false)
        return
      }
      const objIds = (objetivos || []).map(o => o.id).filter(Boolean)
      if (objIds.length === 0) {
        setDados([])
        setSemanasIsoComLancamentoCronograma([])
        setComentariosAtividadeRows([])
        setComentariosIndicadorRows([])
        setAcaoIdsPorTarefaCarometro({})
        setLoading(false)
        return
      }

      const areaIdsDasMetas = [...new Set((objetivos || []).map(o => o.area_id).filter(Boolean))]

      const tf = await selectTarefasCarometro(supabase, objIds, areaIdsDasMetas)
      if (tf.error) {
        setError(tf.error.message)
        setDados([])
        setSemanasIsoComLancamentoCronograma([])
        setComentariosAtividadeRows([])
        setComentariosIndicadorRows([])
        setAcaoIdsPorTarefaCarometro({})
        setLoading(false)
        return
      }
      setSchemaTarefasCar({
        responsavelCol: !!tf.flags?.hasResponsavelCol
      })

      let comps = mesclarComportamentosComMetas(objetivos || [], tf.tCom || [], tf.tarefasSoArea || [])

      const compIds = comps.map(c => c.id)
      const acoesPorTarefa = {}
      /** Cadeia: acoes.tarefa_id → tarefa; caneta_verde = comportamento chave. */
      let acoesRows = []
      if (compIds.length > 0) {
        let selAcoes = 'id, tarefa_id, caneta_verde'
        let { data: ar, error: errA } = await supabase.from('acoes').select(selAcoes).in('tarefa_id', compIds)
        if (errA && erroColunaOuSchemaSupabase(errA)) {
          selAcoes = 'id, tarefa_id'
          const r2 = await supabase.from('acoes').select(selAcoes).in('tarefa_id', compIds)
          ar = r2.data
        }
        acoesRows = ar || []
        for (const a of acoesRows) {
          if (!acoesPorTarefa[a.tarefa_id]) acoesPorTarefa[a.tarefa_id] = []
          acoesPorTarefa[a.tarefa_id].push(a.id)
        }
      }
      comps = comps.map(c => ({
        ...c,
        isChave: comportamentoEhChavePorCaneta(acoesRows.filter(a => a.tarefa_id === c.id))
      }))
      const allAcaoIdsDasMetas = [...new Set(acoesRows.map(a => a.id).filter(Boolean))]

      const semanasArr = [...semanasMemo]
      const p = periodoDb ?? opcoesPeriodo.find(pr => pr.id === selecao) ?? null
      const semanasCalc = semanasArr

      /** UUIDs de `periodos` que intersectam o intervalo do filtro (ex.: mês vs trimestre onde o Gantt gravou). */
      let idsParaFiltro = [selecao].filter(Boolean)
      if (p?.data_inicio && p?.data_fim) {
        const { data: periodosCruzam, error: errCruz } = await supabase
          .from('periodos')
          .select('id')
          .lte('data_inicio', p.data_fim)
          .gte('data_fim', p.data_inicio)
        if (!errCruz && Array.isArray(periodosCruzam) && periodosCruzam.length > 0) {
          const set = new Set(idsParaFiltro)
          periodosCruzam.forEach(row => {
            if (row?.id) set.add(row.id)
          })
          idsParaFiltro = [...set]
        }
      }

      const acaoIdsParaCrono = allAcaoIdsDasMetas
      /** Cronograma: `periodo_id` pode ser trimestre/mês diferente do filtro, desde que as datas se cruzem. */
      const CRONO_SEL = 'acao_id, semana, status, periodo_id'
      const semanaGridArr = semanasCalc.map(s => Number(s)).filter(n => Number.isFinite(n))
      let cronoList = []

      if (acaoIdsParaCrono.length > 0 && semanaGridArr.length > 0 && idsParaFiltro.length > 0) {
        const { data: crTriSem, error: errTriSem } = await supabase
          .from('cronograma')
          .select(CRONO_SEL)
          .in('acao_id', acaoIdsParaCrono)
          .in('semana', semanaGridArr)
          .in('periodo_id', idsParaFiltro)
        if (!errTriSem) cronoList = crTriSem || []
      }

      if (acaoIdsParaCrono.length > 0 && (!cronoList || cronoList.length === 0) && idsParaFiltro.length > 0) {
        const { data: crTriWide } = await supabase
          .from('cronograma')
          .select(CRONO_SEL)
          .in('acao_id', acaoIdsParaCrono)
          .in('periodo_id', idsParaFiltro)
        const filtrado = (crTriWide || []).filter(cr => {
          const w = semanaIsoNaGradeCronograma(cr, semanasCalc)
          return w != null && semanaGridArr.includes(Number(w))
        })
        cronoList = filtrado
      }

      const semSetIsoCrono = new Set()
      for (const cr of cronoList || []) {
        const wIso = semanaIsoNaGradeCronograma(cr, semanasCalc)
        if (wIso != null && Number.isFinite(Number(wIso))) semSetIsoCrono.add(Number(wIso))
      }
      const semanasIsoLancamentoCronoArr = Array.from(semSetIsoCrono)

      let ganttPlano = []
      if (allAcaoIdsDasMetas.length > 0 && idsParaFiltro.length > 0) {
        const GANTT_SEL_FULL = 'id, acao_id, semana_inicio, semana_fim, semanas_selecionadas, periodo_id'
        const GANTT_SEL_MIN = 'acao_id, semana_inicio, semana_fim, semanas_selecionadas, periodo_id'
        let resGp = await supabase
          .from('gantt_planejamento')
          .select(GANTT_SEL_FULL)
          .in('acao_id', allAcaoIdsDasMetas)
          .in('periodo_id', idsParaFiltro)
        if (resGp.error && erroColunaOuSchemaSupabase(resGp.error)) {
          resGp = await supabase
            .from('gantt_planejamento')
            .select(GANTT_SEL_MIN)
            .in('acao_id', allAcaoIdsDasMetas)
            .in('periodo_id', idsParaFiltro)
        }
        ganttPlano = resGp.error ? [] : resGp.data || []
      }

      const semanaAtualIso = getSemanaISOAtual()

      const esforco = {}
      const esforcoPct = {}
      const pctPeriodoPorComportamento = {}
      for (const t of comps) {
        const tid = t.id
        pctPeriodoPorComportamento[tid] = calcularEngajamentoPeriodo(
          tid,
          semanasCalc,
          semanaAtualIso,
          acoesRows,
          cronoList,
          ganttPlano,
          semanasCalc,
          p
        )
        esforco[tid] = {}
        esforcoPct[tid] = {}
        for (const s of semanasCalc) {
          const wn = Number(s)
          const pct = calcularEngajamentoSemana(
            tid,
            wn,
            semanaAtualIso,
            acoesRows,
            cronoList,
            ganttPlano,
            semanasCalc,
            p
          )
          esforcoPct[tid][wn] = pct
          if (pct == null) {
            esforco[tid][wn] = 'ena'
          } else if (pct >= 75) {
            esforco[tid][wn] = 'e100'
          } else if (pct >= 60) {
            esforco[tid][wn] = 'e75'
          } else if (pct >= 30) {
            esforco[tid][wn] = 'e50'
          } else {
            esforco[tid][wn] = 'elow'
          }
        }
      }

      const IND_SEL_SPECS = [
        'id, nome, objetivo_id, area_id, unidade, tipo, regra_verde_escuro, regra_verde_claro, regra_amarelo, regra_verde_escuro_op, regra_verde_claro_op, regra_amarelo_op, indicador_chave, semaforo_faixas',
        'id, nome, objetivo_id, unidade, tipo, regra_verde_escuro, regra_verde_claro, regra_amarelo, regra_verde_escuro_op, regra_verde_claro_op, regra_amarelo_op, indicador_chave, semaforo_faixas',
        'id, nome, objetivo_id, unidade, tipo, regra_verde_escuro, regra_verde_claro, regra_amarelo, regra_verde_escuro_op, regra_verde_claro_op, regra_amarelo_op, indicador_chave',
        'id, nome, objetivo_id'
      ]
      let indicadoresRaw = []
      let errInd = null
      for (const sel of IND_SEL_SPECS) {
        let r = await supabase.from('indicadores').select(sel).in('objetivo_id', objIds).eq('status', 'ativo')
        if (r.error && String(r.error.message || '').toLowerCase().includes('status')) {
          r = await supabase.from('indicadores').select(sel).in('objetivo_id', objIds)
        }
        if (r.error && erroColunaOuSchemaSupabase(r.error)) {
          errInd = r.error
          continue
        }
        if (r.error) {
          errInd = r.error
          break
        }
        indicadoresRaw = r.data || []
        errInd = null
        break
      }
      if (errInd) {
        setError(errInd.message)
      }

      const indList = mesclarIndicadoresNasMetas(objetivos || [], indicadoresRaw || [])
      const indIds = indList.map(i => i.id).filter(Boolean)

      const anosComent =
        p?.data_inicio && p?.data_fim && semanaGridArr.length > 0
          ? [
              ...new Set(
                semanaGridArr
                  .map(sn => anoIsoParaSemanaNoIntervalo(Number(sn), p.data_inicio, p.data_fim))
                  .filter(y => Number.isFinite(Number(y)))
              )
            ]
          : []
      const [rComA, rComI] = await Promise.all([
        allAcaoIdsDasMetas.length > 0 && semanaGridArr.length > 0 && anosComent.length > 0
          ? supabase
              .from('comentarios_atividade')
              .select('id, acao_id, semana_iso, semana_ano, texto, created_at')
              .in('acao_id', allAcaoIdsDasMetas)
              .in('semana_iso', semanaGridArr)
              .in('semana_ano', anosComent)
              .order('semana_iso', { ascending: true })
              .order('created_at', { ascending: true })
          : Promise.resolve({ data: [], error: null }),
        indIds.length > 0 && semanaGridArr.length > 0 && anosComent.length > 0
          ? supabase
              .from('comentarios_indicador')
              .select('id, indicador_id, semana_iso, semana_ano, texto, created_at')
              .in('indicador_id', indIds)
              .in('semana_iso', semanaGridArr)
              .in('semana_ano', anosComent)
              .order('semana_iso', { ascending: true })
              .order('created_at', { ascending: true })
          : Promise.resolve({ data: [], error: null })
      ])
      const comRowsA = !rComA.error ? rComA.data || [] : []
      const comRowsI = !rComI.error ? rComI.data || [] : []

      let lancamentosList = []
      const semanasSetL = new Set(semanasCalc.map(s => Number(s)).filter(n => Number.isFinite(n)))

      if (indIds.length > 0 && idsParaFiltro.length > 0) {
        const LANCAMENTO_SEL = 'indicador_id, semana, valor, periodo_id'

        if (semanasArr.length > 0) {
          const resTri = await supabase
            .from('indicador_lancamentos')
            .select(LANCAMENTO_SEL)
            .in('indicador_id', indIds)
            .in('semana', semanasArr)
            .in('periodo_id', idsParaFiltro)
          if (!resTri.error) lancamentosList = mergeLancRows(lancamentosList, resTri.data || [])
        }

        if (!lancamentosList || lancamentosList.length === 0) {
          const resLeg = await supabase
            .from('indicador_lancamentos')
            .select(LANCAMENTO_SEL)
            .in('indicador_id', indIds)
            .in('periodo_id', idsParaFiltro)
          if (!resLeg.error) {
            const semSetF = new Set(semanasArr.map(s => Number(s)).filter(n => Number.isFinite(n)))
            const rawLeg = resLeg.data || []
            const filtradoLeg =
              semSetF.size > 0
                ? rawLeg.filter(row => {
                    const iso = semanaLancamentoIndicadorParaGrade(row, semSetF)
                    return iso != null && semSetF.has(Number(iso))
                  })
                : rawLeg
            lancamentosList = mergeLancRows(lancamentosList, filtradoLeg.length ? filtradoLeg : rawLeg)
          }
        }

        lancamentosList = ordenarLancamentosIndicadorParaGradeCar(lancamentosList)
      }

      const semaf = {}
      for (const ind of indList) {
        semaf[ind.id] = {}
        for (const s of semanasCalc) {
          const wn = Number(s)
          let match = null
          for (const l of lancamentosList || []) {
            if (l.indicador_id !== ind.id) continue
            const iso = semanaLancamentoIndicadorParaGrade(l, semanasSetL)
            if (iso === wn) match = l
          }
          if (!match || match.valor == null || String(match.valor).trim() === '') {
            semaf[ind.id][wn] = 'ina'
          } else {
            semaf[ind.id][wn] = statusCarometroIndicadorCelula(ind, match.valor)
          }
        }
      }

      const indValorPorSemana = {}
      for (const ind of indList) {
        indValorPorSemana[ind.id] = {}
        for (const s of semanasCalc) {
          const wn = Number(s)
          let match = null
          for (const l of lancamentosList || []) {
            if (l.indicador_id !== ind.id) continue
            const iso = semanaLancamentoIndicadorParaGrade(l, semanasSetL)
            if (iso === wn) match = l
          }
          indValorPorSemana[ind.id][wn] =
            match?.valor != null && String(match.valor).trim() !== '' ? match.valor : null
        }
      }

      const areasFilt =
        areaSelecionada === 'geral' ? areasData || [] : (areasData || []).filter(a => a.id === areaSelecionada)

      const estrutura = agruparPorAreaEMeta({
        areas: areasFilt,
        objetivos: objetivos || [],
        tarefas: comps,
        indicadores: indList,
        esforco,
        esforcoPct,
        pctPeriodoPorComportamento,
        semaf,
        indValorPorSemana,
        semanas: semanasArr,
        visualizacao
      })
      if (depsFetch.current === key) {
        setDados(estrutura)
        setSemanasIsoComLancamentoCronograma(semanasIsoLancamentoCronoArr)
        setComentariosAtividadeRows(comRowsA)
        setComentariosIndicadorRows(comRowsI)
        setAcaoIdsPorTarefaCarometro(acoesPorTarefa)
        setLoading(false)
      }
    } catch (err) {
      setError(String(err?.message || err))
      setSemanasIsoComLancamentoCronograma([])
      setComentariosAtividadeRows([])
      setComentariosIndicadorRows([])
      setAcaoIdsPorTarefaCarometro({})
      setLoading(false)
    }
  }, [
    selecao,
    areaSelecionada,
    periodoDb?.id,
    periodoDb?.data_inicio,
    periodoDb?.data_fim,
    opcoesPeriodo,
    semanasKey,
    visualizacao
  ])

  useEffect(() => {
    carregarDados()
  }, [carregarDados])

  async function toggleChaveTarefa(t) {
    if (!isAdmin) return
    const atual = !!t.is_chave
    const novo = !atual
    setSalvandoChave(`t-${t.id}`)
    setDados(prev =>
      prev.map(block => ({
        ...block,
        metas: block.metas.map(m => ({
          ...m,
          comportamentos: m.comportamentos.map(c => (c.id === t.id ? { ...c, isChave: novo } : c))
        }))
      }))
    )
    let res = await supabase
      .from('acoes')
      .update({ caneta_verde: novo ? 'sim' : 'nao' })
      .eq('tarefa_id', t.id)
    if (res.error && erroColunaOuSchemaSupabase(res.error)) {
      res = await supabase.from('tarefas').update({ is_chave: novo }).eq('id', t.id)
    }
    if (res.error) {
      console.error('[Carometro] erro ao salvar chave tarefa:', res.error.message)
      setError('Não foi possível salvar. Verifique a configuração do banco.')
      return
    }
    if (res.error) {
      setDados(prev =>
        prev.map(block => ({
          ...block,
          metas: block.metas.map(m => ({
            ...m,
            comportamentos: m.comportamentos.map(c => (c.id === t.id ? { ...c, isChave: atual } : c))
          }))
        }))
      )
      setError(res.error.message)
    } else {
      void registrarLog({
        modulo: 'Carômetro',
        area: areaSelecionada?.nome,
        entidade: 'tarefa',
        entidade_id: t.id,
        operacao: 'UPDATE',
        valor_anterior: { is_chave: atual },
        valor_novo: { is_chave: novo },
        descricao: `Alterou chave da tarefa "${t.nome || t.id}"`
      })
    }
    setSalvandoChave(null)
  }

  async function toggleChaveIndicador(ind) {
    if (!isAdmin) return
    const atual = !!ind.isChave
    const novo = !atual
    setSalvandoChave(`i-${ind.id}`)
    setDados(prev =>
      prev.map(block => ({
        ...block,
        metas: block.metas.map(m => ({
          ...m,
          indicadores: m.indicadores.map(i =>
            i.id === ind.id ? { ...i, isChave: novo, indicador_chave: novo } : i
          )
        }))
      }))
    )
    let res = await supabase.from('indicadores').update({ indicador_chave: novo }).eq('id', ind.id)
    if (res.error && erroColunaOuSchemaSupabase(res.error)) {
      res = await supabase.from('indicadores').update({ is_chave: novo }).eq('id', ind.id)
    }
    if (res.error && erroColunaOuSchemaSupabase(res.error)) {
      res = await supabase.from('indicadores').update({ chave: novo }).eq('id', ind.id)
    }
    if (res.error) {
      console.error('[Carometro] erro ao salvar chave indicador:', res.error.message)
      setError('Não foi possível salvar. Verifique a configuração do banco.')
      return
    }
    if (res.error) {
      setDados(prev =>
        prev.map(block => ({
          ...block,
          metas: block.metas.map(m => ({
            ...m,
            indicadores: m.indicadores.map(i =>
              i.id === ind.id ? { ...i, isChave: atual, indicador_chave: atual } : i
            )
          }))
        }))
      )
      setError(res.error.message)
    } else {
      void registrarLog({
        modulo: 'Carômetro',
        area: areaSelecionada?.nome,
        entidade: 'indicadores',
        entidade_id: ind.id,
        operacao: 'UPDATE',
        valor_anterior: { indicador_chave: atual, is_chave: atual },
        valor_novo: { indicador_chave: novo, is_chave: novo },
        descricao: `Alterou indicador chave "${ind.nome || ind.id}"`
      })
    }
    setSalvandoChave(null)
  }

  const dadosProcessados = useMemo(() => {
    const sel = (areasMultiplas || []).filter(Boolean)
    if (!sel.length || sel.includes('geral')) return dados
    const set = new Set(sel)
    return (dados || []).filter(b => {
      const id = b?.area?.id
      return id && set.has(id)
    })
  }, [dados, areasMultiplas])

  const resumoExecutivo = useMemo(() => {
    const empty = {
      compAtivos: 0,
      engMedio: null,
      compOk: [0, 0],
      pctCompOk: 0,
      indAtivos: 0,
      indAtingidos: [0, 0],
      pctIndAting: 0,
      indRisco: 0,
      indResMedio: null,
      pctIndSaude: 0
    }
    if (!dadosProcessados?.length || !semanasVisiveis.length) return empty
    const wAtual = getSemanaISOAtual()
    const semanasDoPeriodo = (semanasMemo && semanasMemo.length ? semanasMemo : semanasVisiveis) || []
    let compAtivos = 0
    const medias = []
    let ok = 0
    let indAtivos = 0
    let ating = 0
    let risco = 0
    const ultW = semanasVisiveis[semanasVisiveis.length - 1]
    let indResSoma = 0
    let indResN = 0
    const scMap = { ive: 100, ivc: 67, iam: 45, ivm: 15 }
    for (const block of dadosProcessados) {
      for (const meta of block.metas) {
        for (const c of meta.comportamentos) {
          compAtivos++
          const semanasComDado = semanasDoPeriodo.filter(wn => {
            const val = c.pctSemanas?.[Number(wn)]
            return val != null && !Number.isNaN(val) && Number(wn) < wAtual
          })
          const avg =
            semanasComDado.length > 0
              ? semanasComDado.reduce((s, wn) => s + c.pctSemanas[Number(wn)], 0) / semanasComDado.length
              : c.pctPeriodo != null && !Number.isNaN(c.pctPeriodo)
                ? c.pctPeriodo
                : null
          if (avg != null) {
            medias.push(avg)
            if (avg >= 60) ok++
          }
        }
        for (const ind of meta.indicadores) {
          indAtivos++
          const st = statusUltimoIndicador(ind.semanas || {}, semanasVisiveis)
          const mediaInd = mediaPctIndicador(ind.semanas || {}, semanasVisiveis)
          if (mediaInd != null && mediaInd >= 60) ating++
          if (st === 'iam' || st === 'ivm') risco++
          const semanasIndComDado = semanasDoPeriodo.filter(wn => {
            const cod = ind.semanas?.[Number(wn)]
            return cod && cod !== 'ina' && scMap[cod] != null && Number(wn) < wAtual
          })
          if (semanasIndComDado.length > 0) {
            const somaInd = semanasIndComDado.reduce((s, wn) => s + scMap[ind.semanas[Number(wn)]], 0)
            indResSoma += somaInd / semanasIndComDado.length
            indResN++
          }
        }
      }
    }
    const engMedio = medias.length ? medias.reduce((a, b) => a + b, 0) / medias.length : null
    const pctCompOk = compAtivos ? Math.round((100 * ok) / compAtivos) : 0
    const pctIndAting = indAtivos ? Math.round((100 * ating) / indAtivos) : 0
    const indResMedio = indResN ? indResSoma / indResN : null
    const pctIndSaude = indAtivos ? Math.round((100 * (indAtivos - risco)) / indAtivos) : 0
    return {
      compAtivos,
      engMedio,
      compOk: [ok, compAtivos],
      pctCompOk,
      indAtivos,
      indAtingidos: [ating, indAtivos],
      pctIndAting,
      indRisco: risco,
      indResMedio,
      pctIndSaude
    }
  }, [dadosProcessados, semanasVisiveis, semanasMemo])

  const resumoCardsVisual = useMemo(() => {
    const engajamentoMedioPct =
      resumoExecutivo.engMedio != null ? Math.round(resumoExecutivo.engMedio) : null
    const indicadorMedioPct =
      resumoExecutivo.indResMedio != null ? Math.round(resumoExecutivo.indResMedio) : null
    const [compAtingidos, totalComp] = resumoExecutivo.compOk
    const pctAtingidosComp =
      totalComp > 0 ? Math.round((compAtingidos / totalComp) * 100) : null
    const [atingInd, totalInd] = resumoExecutivo.indAtingidos
    const pctAtingidosInd =
      totalInd > 0 ? Math.round((atingInd / totalInd) * 100) : null
    return {
      engajamentoMedioPct,
      indicadorMedioPct,
      rmComp: getCorPorcentagem(engajamentoMedioPct),
      rmInd: getCorPorcentagem(indicadorMedioPct),
      pctAtingidosComp,
      atgComp: getCorPorcentagem(pctAtingidosComp),
      pctAtingidosInd,
      atgInd: getCorPorcentagem(pctAtingidosInd)
    }
  }, [resumoExecutivo])

  const resultadoMedioMesComp = resumoCardsVisual.engajamentoMedioPct
  const resultadoMedioMesInd = resumoCardsVisual.indicadorMedioPct

  const carinhaVisible = dadosProcessados?.length > 0 && semanasVisiveis?.length > 0

  const codigoCarinhaComportamentos = useMemo(
    () => bandPctParaCodigoComportamento(calcularCodigoPorResultadoMedio(resultadoMedioMesComp)),
    [resultadoMedioMesComp]
  )

  const codigoCarinhaIndicadores = useMemo(
    () => calcularCodigoPorResultadoMedio(resultadoMedioMesInd),
    [resultadoMedioMesInd]
  )

  /**
   * Cards de resumo: semana de referência = última semana ISO **anterior** à atual com ≥1 linha no cronograma;
   * fallback `semanaAtual - 1`. A semana corrente costuma estar em aberto, sem dado consolidado.
   */
  const metricasSemanaAtual = useMemo(() => {
    const wA = getSemanaISOAtual()
    const wRef = Math.max(1, wA - 1)
    const labelTagSemana = `S${wRef} ★ semana anterior`
    const scMap = { ive: 100, ivc: 67, iam: 45, ivm: 15 }
    const pctsComp = []
    let atingComp = 0
    let nComp = 0
    const valsInd = []
    let atingInd = 0
    let nInd = 0
    if (dadosProcessados?.length) {
      for (const block of dadosProcessados) {
        for (const meta of block.metas) {
          for (const c of meta.comportamentos) {
            nComp++
            const p = c.pctSemanas?.[Number(wRef)]
            if (p != null && !Number.isNaN(p)) {
              pctsComp.push(p)
              if (p >= 60) atingComp++
            }
          }
          for (const ind of meta.indicadores) {
            nInd++
            const cod = ind.semanas?.[Number(wRef)]
            const v = cod && cod !== 'ina' ? scMap[cod] : null
            if (v != null) {
              valsInd.push(v)
              if (v >= 60) atingInd++
            }
          }
        }
      }
    }
    const mediaComp =
      pctsComp.length > 0 ? pctsComp.reduce((a, b) => a + b, 0) / pctsComp.length : null
    const mediaInd =
      valsInd.length > 0 ? valsInd.reduce((a, b) => a + b, 0) / valsInd.length : null
    const pctAtingComp = nComp > 0 ? Math.round((atingComp / nComp) * 100) : null
    const pctAtingInd = nInd > 0 ? Math.round((atingInd / nInd) * 100) : null
    return {
      semanaISO: wRef,
      semanaAtualISO: wA,
      labelTagSemana,
      comp: {
        mediaPct: mediaComp != null ? Math.round(mediaComp) : null,
        atingidos: atingComp,
        total: nComp,
        pctAting: pctAtingComp,
        atg: getCorPorcentagem(pctAtingComp),
        rm: getCorPorcentagem(mediaComp != null ? Math.round(mediaComp) : null)
      },
      ind: {
        mediaPct: mediaInd != null ? Math.round(mediaInd) : null,
        atingidos: atingInd,
        total: nInd,
        pctAting: pctAtingInd,
        atg: getCorPorcentagem(pctAtingInd),
        rm: getCorPorcentagem(mediaInd != null ? Math.round(mediaInd) : null)
      }
    }
  }, [dadosProcessados, semanasIsoComLancamentoCronograma])

  const labelTagPeriodoFiltro = periodoDb ? labelPeriodo(periodoDb) : '—'

  function corValorGrandeIndicador(pct) {
    if (pct === null || pct === undefined || Number.isNaN(pct)) return 'var(--color-text-secondary)'
    if (pct >= 60) return '#0c447c'
    if (pct >= 30) return '#e6a817'
    return '#b71c1c'
  }

  const labelStyle = {
    fontSize: 10,
    textTransform: 'uppercase',
    letterSpacing: '0.06em',
    display: 'block',
    marginBottom: 4,
    opacity: 0.85
  }

  const filtrosRef = useRef(null)
  const [filtrosOpen, setFiltrosOpen] = useState(false)
  const [secOpen, setSecOpen] = useState({
    periodo: false,
    selecao: false,
    area: false,
    visualizacao: false
  })
  const [areaBusca, setAreaBusca] = useState('')

  const [draftPeriodo, setDraftPeriodo] = useState(periodo)
  const [draftSelecoes, setDraftSelecoes] = useState([])
  const [draftAreas, setDraftAreas] = useState(['geral'])
  const [draftVisualizacao, setDraftVisualizacao] = useState(visualizacao)

  useEffect(() => {
    if (!filtrosOpen) return
    setDraftPeriodo(periodo)
    setDraftSelecoes((selecaoMultipla && selecaoMultipla.length ? selecaoMultipla : (selecao ? [selecao] : [])).filter(Boolean))
    setDraftAreas((areasMultiplas && areasMultiplas.length ? areasMultiplas : (areaSelecionada ? [areaSelecionada] : ['geral'])).filter(Boolean))
    setDraftVisualizacao(visualizacao)
    setAreaBusca('')
  }, [filtrosOpen, periodo, selecao, selecaoMultipla, areaSelecionada, areasMultiplas, visualizacao])

  useEffect(() => {
    function onDown(e) {
      if (!filtrosOpen) return
      const el = filtrosRef.current
      if (el && e.target && el.contains(e.target)) return
      setFiltrosOpen(false)
    }
    document.addEventListener('mousedown', onDown)
    return () => document.removeEventListener('mousedown', onDown)
  }, [filtrosOpen])

  useEffect(() => {
    let cancel = false
    async function loadOpcoesDraft() {
      if (!filtrosOpen) return
      const { data, error: e } = await supabase
        .from('periodos')
        .select('*')
        .eq('tipo', draftPeriodo)
        .order('ano', { ascending: false })
        .order('numero', { ascending: false })
      if (cancel) return
      if (e) {
        setOpcoesPeriodoDraft([])
        return
      }
      setOpcoesPeriodoDraft(data || [])
      const validIds = new Set((data || []).map(p => p.id).filter(Boolean))
      setDraftSelecoes(prev => {
        const cur = (prev || []).filter(x => validIds.has(x))
        if (cur.length) return cur
        const first = data?.[0]?.id
        return first ? [first] : []
      })
    }
    loadOpcoesDraft()
    return () => {
      cancel = true
    }
  }, [draftPeriodo, filtrosOpen])

  const periodoLabelAtual =
    periodo === 'mes'
      ? 'Mês'
      : periodo === 'bimestre'
        ? 'Bimestre'
        : periodo === 'trimestre'
          ? 'Trimestre'
          : periodo === 'semestre'
            ? 'Semestre'
            : 'Ano'

  const selecaoLabelAtual = useMemo(() => {
    const ids = (selecaoMultipla || []).filter(Boolean)
    if (!ids.length) return '—'
    if (ids.length > 1) return `${ids.length} selecionados`
    const row = (opcoesPeriodo || []).find(p => p.id === ids[0]) || periodoDb
    return row ? labelPeriodo(row) : '—'
  }, [selecaoMultipla, opcoesPeriodo, periodoDb])

  const areaLabelAtual = useMemo(() => {
    const sel = (areasMultiplas || []).filter(Boolean)
    if (!sel.length || sel.includes('geral')) return 'Geral (todas)'
    if (sel.length > 1) return `${sel.length} áreas`
    const ar = (areas || []).find(a => a.id === sel[0])
    return ar?.nome || '—'
  }, [areasMultiplas, areas])

  const visLabelAtual = visualizacao === 'chave' ? 'Só chave' : 'Todos'

  const filtrosAtivos = useMemo(() => {
    const out = []
    if (periodo !== 'mes') out.push({ key: 'periodo', label: `Período: ${periodoLabelAtual}` })
    if (selecaoMultipla?.length && opcoesPeriodo?.[0]?.id) {
      const first = opcoesPeriodo[0].id
      const ids = (selecaoMultipla || []).filter(Boolean)
      if (ids.length !== 1 || ids[0] !== first) out.push({ key: 'selecao', label: `Seleção: ${selecaoLabelAtual}` })
    }
    if (areasMultiplas?.length) {
      const sel = (areasMultiplas || []).filter(Boolean)
      if (!(sel.length === 1 && sel[0] === 'geral')) out.push({ key: 'area', label: `Área: ${areaLabelAtual}` })
    }
    if (visualizacao !== 'geral') out.push({ key: 'visualizacao', label: `Visualização: ${visLabelAtual}` })
    return out
  }, [periodo, selecaoMultipla, opcoesPeriodo, selecaoLabelAtual, areasMultiplas, areaLabelAtual, visualizacao, periodoLabelAtual, visLabelAtual])

  const totalFiltrosAtivos = filtrosAtivos.length

  function limparTudoAplicado() {
    setPeriodo('mes')
    setSelecao(opcoesPeriodo?.[0]?.id || '')
    setSelecaoMultipla(opcoesPeriodo?.[0]?.id ? [opcoesPeriodo[0].id] : [])
    setAreaSelecionada('geral')
    setAreasMultiplas(['geral'])
    setVisualizacao('geral')
  }

  function removerFiltro(key) {
    if (key === 'periodo') setPeriodo('mes')
    if (key === 'selecao') {
      const first = opcoesPeriodo?.[0]?.id || ''
      setSelecao(first)
      setSelecaoMultipla(first ? [first] : [])
    }
    if (key === 'area') {
      setAreaSelecionada('geral')
      setAreasMultiplas(['geral'])
    }
    if (key === 'visualizacao') setVisualizacao('geral')
  }

  return (
    <div
      className="carometro-page-v2 carometro-scorecard"
      style={{ padding: '0 0 2rem', fontFamily: 'system-ui, -apple-system, Segoe UI, Roboto, sans-serif' }}
    >
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 12 }}>
        <div style={{ minWidth: 0 }}>
          <h1 style={{ fontSize: '1.35rem', fontWeight: 700, marginBottom: 6 }}>
            Carômetro — Scorecard Executivo
          </h1>
          <p style={{ marginBottom: 12, color: 'var(--color-text-secondary, #4a5568)', fontSize: 14 }}>
            Acompanhamento semanal de metas, comportamentos e indicadores por área.
          </p>
        </div>
        <div ref={filtrosRef} style={{ position: 'relative', flexShrink: 0 }}>
          <button
            type="button"
            onClick={() => setFiltrosOpen(v => !v)}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 8,
              background: 'var(--comp-mid)',
              color: 'var(--hdr-text)',
              border: 'none',
              borderRadius: 8,
              padding: '9px 16px',
              fontSize: 13,
              fontWeight: 500,
              cursor: 'pointer',
              position: 'relative'
            }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path
                d="M4 6h16M7 12h10M10 18h4"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
              />
            </svg>
            Filtros
            <span
              style={{
                background: 'var(--surf0)',
                color: 'var(--comp-mid)',
                borderRadius: 10,
                fontSize: 11,
                fontWeight: 500,
                padding: '1px 7px'
              }}
            >
              {totalFiltrosAtivos}
            </span>
          </button>

          {filtrosOpen && (
            <div
              style={{
                position: 'absolute',
                top: 'calc(100% + 8px)',
                right: 0,
                width: 280,
                background: 'var(--color-background-primary)',
                border: '0.5px solid var(--color-border-secondary)',
                borderRadius: 10,
                boxShadow: '0 4px 16px rgba(0,0,0,0.10)',
                zIndex: 200,
                overflow: 'hidden'
              }}
            >
              <div
                style={{
                  padding: '11px 14px',
                  borderBottom: '0.5px solid var(--color-border-tertiary)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  gap: 10
                }}
              >
                <div style={{ fontSize: 13, fontWeight: 500 }}>Filtros</div>
                <button
                  type="button"
                  onClick={() => {
                    setDraftPeriodo('mes')
                    setDraftSelecoes(opcoesPeriodoDraft?.[0]?.id ? [opcoesPeriodoDraft[0].id] : [])
                    setDraftAreas(['geral'])
                    setDraftVisualizacao('geral')
                  }}
                  style={{
                    border: 'none',
                    background: 'transparent',
                    padding: 0,
                    fontSize: 11,
                    color: 'var(--ind-light)',
                    cursor: 'pointer'
                  }}
                >
                  Limpar tudo
                </button>
              </div>

              {[
                {
                  key: 'periodo',
                  label: 'Período',
                  value:
                    draftPeriodo === 'mes'
                      ? 'Mês'
                      : draftPeriodo === 'bimestre'
                        ? 'Bimestre'
                        : draftPeriodo === 'trimestre'
                          ? 'Trimestre'
                          : draftPeriodo === 'semestre'
                            ? 'Semestre'
                            : 'Ano',
                  open: secOpen.periodo,
                  onToggle: () => setSecOpen(s => ({ ...s, periodo: !s.periodo })),
                  body: (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                      {[
                        { id: 'mes', label: 'Mês' },
                        { id: 'bimestre', label: 'Bimestre' },
                        { id: 'trimestre', label: 'Trimestre' },
                        { id: 'semestre', label: 'Semestre' },
                        { id: 'ano', label: 'Ano' }
                      ].map(opt => (
                        <label
                          key={opt.id}
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: 8,
                            padding: '4px 6px',
                            borderRadius: 5,
                            cursor: 'pointer'
                          }}
                          onMouseEnter={e => (e.currentTarget.style.background = 'var(--color-background-secondary)')}
                          onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
                        >
                          <input
                            type="radio"
                            name="car-filtro-periodo"
                            checked={draftPeriodo === opt.id}
                            onChange={() => {
                              setDraftPeriodo(opt.id)
                              setDraftSelecoes([])
                            }}
                            style={{ accentColor: 'var(--comp-light)', width: 14, height: 14 }}
                          />
                          <span style={{ fontSize: 13, fontWeight: draftPeriodo === opt.id ? 500 : 400 }}>
                            {opt.label}
                          </span>
                        </label>
                      ))}
                    </div>
                  )
                },
                {
                  key: 'selecao',
                  label: 'Seleção',
                  value: (() => {
                    const ids = (draftSelecoes || []).filter(Boolean)
                    if (!ids.length) return '—'
                    if (ids.length > 1) return `${ids.length} selecionados`
                    const row = (opcoesPeriodoDraft || []).find(p => p.id === ids[0])
                    return row ? labelPeriodo(row) : '—'
                  })(),
                  open: secOpen.selecao,
                  onToggle: () => setSecOpen(s => ({ ...s, selecao: !s.selecao })),
                  body: (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 4, maxHeight: 220, overflow: 'auto' }}>
                      {(opcoesPeriodoDraft || []).map(p => (
                        (() => {
                          const checked = (draftSelecoes || []).includes(p.id)
                          return (
                        <label
                          key={p.id}
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: 8,
                            padding: '4px 6px',
                            borderRadius: 5,
                            cursor: 'pointer'
                          }}
                          onMouseEnter={e => (e.currentTarget.style.background = 'var(--color-background-secondary)')}
                          onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
                        >
                          <input
                            type="checkbox"
                            checked={checked}
                            onChange={() => {
                              setDraftSelecoes(prev => {
                                const cur = prev || []
                                if (cur.includes(p.id) && cur.length === 1) return cur
                                return cur.includes(p.id) ? cur.filter(x => x !== p.id) : [...cur, p.id]
                              })
                            }}
                            style={{ accentColor: 'var(--comp-light)', width: 14, height: 14 }}
                          />
                          <span style={{ fontSize: 13, fontWeight: checked ? 500 : 400 }}>
                            {labelPeriodo(p)}
                          </span>
                        </label>
                          )
                        })()
                      ))}
                    </div>
                  )
                },
                {
                  key: 'area',
                  label: 'Área',
                  value:
                    (draftAreas || []).includes('geral')
                      ? 'Geral (todas)'
                      : (draftAreas || []).length === 1
                        ? (areas || []).find(a => a.id === (draftAreas || [])[0])?.nome || '—'
                        : `${(draftAreas || []).length} áreas`,
                  open: secOpen.area,
                  onToggle: () => setSecOpen(s => ({ ...s, area: !s.area })),
                  body: (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                      <input
                        type="text"
                        value={areaBusca}
                        onChange={e => setAreaBusca(e.target.value)}
                        placeholder="Buscar área..."
                        style={{
                          height: 32,
                          padding: '0 10px',
                          borderRadius: 8,
                          border: '0.5px solid var(--color-border-secondary)',
                          background: 'var(--color-background-primary)',
                          fontSize: 13
                        }}
                      />
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 4, maxHeight: 220, overflow: 'auto' }}>
                        {(() => {
                          const term = String(areaBusca || '').trim().toLowerCase()
                          const areasFiltradas = term
                            ? (areas || []).filter(a => String(a.nome || '').toLowerCase().includes(term))
                            : (areas || [])
                          const rows = [{ id: 'geral', nome: 'Geral (todas)' }, ...areasFiltradas]
                          return rows.map(a => (
                            (() => {
                              const checked = (draftAreas || []).includes(a.id)
                              return (
                            <label
                              key={a.id}
                              style={{
                                display: 'flex',
                                alignItems: 'center',
                                gap: 8,
                                padding: '4px 6px',
                                borderRadius: 5,
                                cursor: 'pointer'
                              }}
                              onMouseEnter={e => (e.currentTarget.style.background = 'var(--color-background-secondary)')}
                              onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
                            >
                              <input
                                type="checkbox"
                                checked={checked}
                                onChange={() => {
                                  if (a.id === 'geral') {
                                    setDraftAreas(['geral'])
                                    return
                                  }
                                  setDraftAreas(prev => {
                                    const cur = prev || []
                                    const semGeral = cur.filter(x => x !== 'geral')
                                    if (semGeral.includes(a.id)) {
                                      const novo = semGeral.filter(x => x !== a.id)
                                      return novo.length === 0 ? ['geral'] : novo
                                    }
                                    return [...semGeral, a.id]
                                  })
                                }}
                                style={{ accentColor: 'var(--comp-light)', width: 14, height: 14 }}
                              />
                              <span style={{ fontSize: 13, fontWeight: checked ? 500 : 400 }}>
                                {a.nome}
                              </span>
                            </label>
                              )
                            })()
                          ))
                        })()}
                      </div>
                    </div>
                  )
                },
                {
                  key: 'visualizacao',
                  label: 'Visualização',
                  value: draftVisualizacao === 'chave' ? 'Só chave' : 'Todos',
                  open: secOpen.visualizacao,
                  onToggle: () => setSecOpen(s => ({ ...s, visualizacao: !s.visualizacao })),
                  body: (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                      {[
                        { id: 'geral', label: 'Todos os comportamentos' },
                        { id: 'chave', label: 'Só chave' }
                      ].map(opt => (
                        <label
                          key={opt.id}
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: 8,
                            padding: '4px 6px',
                            borderRadius: 5,
                            cursor: 'pointer'
                          }}
                          onMouseEnter={e => (e.currentTarget.style.background = 'var(--color-background-secondary)')}
                          onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
                        >
                          <input
                            type="radio"
                            name="car-filtro-vis"
                            checked={draftVisualizacao === opt.id}
                            onChange={() => setDraftVisualizacao(opt.id)}
                            style={{ accentColor: 'var(--comp-light)', width: 14, height: 14 }}
                          />
                          <span style={{ fontSize: 13, fontWeight: draftVisualizacao === opt.id ? 500 : 400 }}>
                            {opt.label}
                          </span>
                        </label>
                      ))}
                    </div>
                  )
                }
              ].map((sec, idx, arr) => (
                <div
                  key={sec.key}
                  style={{
                    padding: '10px 14px',
                    borderBottom: idx === arr.length - 1 ? 'none' : '0.5px solid var(--color-border-tertiary)'
                  }}
                >
                  <button
                    type="button"
                    onClick={sec.onToggle}
                    style={{
                      width: '100%',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: 10,
                      border: 'none',
                      background: 'transparent',
                      padding: 0,
                      cursor: 'pointer'
                    }}
                  >
                    <div style={{ textAlign: 'left' }}>
                      <div
                        style={{
                          fontSize: 11,
                          textTransform: 'uppercase',
                          color: 'var(--color-text-secondary)',
                          opacity: 0.9
                        }}
                      >
                        {sec.label}
                      </div>
                      <div style={{ fontSize: 13, fontWeight: 500, marginTop: 2, color: 'var(--color-text-primary)' }}>
                        {sec.value}
                      </div>
                    </div>
                    <div style={{ fontSize: 12, color: 'var(--color-text-secondary)' }}>{sec.open ? '▴' : '▾'}</div>
                  </button>
                  {sec.open && <div style={{ marginTop: 10 }}>{sec.body}</div>}
                </div>
              ))}

              <div
                style={{
                  padding: '10px 14px',
                  display: 'flex',
                  justifyContent: 'flex-end',
                  gap: 10,
                  borderTop: '0.5px solid var(--color-border-tertiary)'
                }}
              >
                <button
                  type="button"
                  onClick={() => setFiltrosOpen(false)}
                  style={{
                    border: '0.5px solid var(--color-border-secondary)',
                    background: 'transparent',
                    borderRadius: 8,
                    padding: '8px 12px',
                    fontSize: 12,
                    cursor: 'pointer'
                  }}
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setPeriodo(draftPeriodo)
                    setSelecao((draftSelecoes || [])[0] || '')
                    setSelecaoMultipla((draftSelecoes || []).filter(Boolean))
                    const nextAreas = (draftAreas || []).filter(Boolean)
                    const areasFinal = nextAreas.length ? (nextAreas.includes('geral') ? ['geral'] : nextAreas) : ['geral']
                    setAreasMultiplas(areasFinal)
                    setAreaSelecionada(areasFinal.includes('geral') ? 'geral' : (areasFinal[0] || 'geral'))
                    setVisualizacao(draftVisualizacao === 'chave' ? 'chave' : 'geral')
                    setFiltrosOpen(false)
                  }}
                  style={{
                    border: 'none',
                    background: 'var(--comp-mid)',
                    color: 'var(--hdr-text)',
                    borderRadius: 8,
                    padding: '8px 12px',
                    fontSize: 12,
                    cursor: 'pointer'
                  }}
                >
                  Aplicar
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
      {error && (
        <div className="alert alert-error" style={{ marginBottom: 12 }}>
          {error}
        </div>
      )}

      {filtrosAtivos.length > 0 && (
        <div
          style={{
            display: 'flex',
            gap: 6,
            flexWrap: 'wrap',
            alignItems: 'center',
            marginBottom: 14
          }}
        >
          <span style={{ fontSize: 11, color: 'var(--color-text-secondary)' }}>Ativos:</span>
          {filtrosAtivos.map(f => (
            <span
              key={f.key}
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: 4,
                background: 'var(--color-background-secondary)',
                border: '0.5px solid var(--color-border-secondary)',
                borderRadius: 12,
                padding: '3px 10px',
                fontSize: 11
              }}
            >
              {f.label}
              <span
                onClick={() => removerFiltro(f.key)}
                style={{ cursor: 'pointer', fontSize: 12, color: 'var(--color-text-secondary)' }}
              >
                ×
              </span>
            </span>
          ))}
          <button
            type="button"
            onClick={limparTudoAplicado}
            style={{
              border: 'none',
              background: 'transparent',
              padding: '3px 6px',
              fontSize: 11,
              color: 'var(--ind-light)',
              cursor: 'pointer'
            }}
          >
            Limpar tudo
          </button>
        </div>
      )}

      <div
        style={{
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: 16,
          alignItems: 'stretch',
          marginBottom: 14
        }}
      >
        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            height: '100%',
            minHeight: 0,
            borderRadius: 8,
            overflow: 'hidden',
            border: '0.5px solid var(--comp-bdr)'
          }}
        >
          <div
            style={{
              background: 'var(--comp-mid)',
              padding: '12px 16px',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: 4
            }}
          >
            <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--hdr-text)', textAlign: 'center' }}>
              Meta / Comportamento — Engajamento
            </div>
            <div style={{ fontSize: 11, color: 'var(--hdr-sub)', textAlign: 'center' }}>
              {resumoExecutivo.compAtivos} comportamentos ativos no período
            </div>
          </div>
          <div
            style={{
              flex: 1,
              minHeight: 0,
              background: 'var(--comp-bg)',
              padding: 16,
              display: 'flex',
              flexDirection: 'column'
            }}
          >
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 12,
                flex: 1,
                minHeight: 0
              }}
            >
              <CarinhaBlocoResumo
                tipo="comp"
                codigo={codigoCarinhaComportamentos}
                labelColor={corLabelFaixaResultadoMedioMes(resultadoMedioMesComp)}
                imgAlt="carinha engajamento"
                carinhaVisible={carinhaVisible}
              />
              <div
                style={{
                  width: '0.5px',
                  minWidth: '0.5px',
                  alignSelf: 'stretch',
                  background: 'rgba(0, 0, 0, 0.12)',
                  margin: '0 4px',
                  flexShrink: 0
                }}
              />
              <div
                style={{
                  flex: 1,
                  display: 'grid',
                  gridTemplateColumns: '1fr 1fr',
                  gap: 0,
                  minWidth: 0
                }}
              >
                <div
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    textAlign: 'center',
                    padding: '0 6px'
                  }}
                >
                  <div style={{ fontSize: 11, color: '#555', fontWeight: 500, marginBottom: 8 }}>
                    Atingidos (≥60%)
                  </div>

                  <div>
                    <span
                      style={{
                        display: 'inline-block',
                        fontSize: 10,
                        fontWeight: 500,
                        borderRadius: 10,
                        padding: '2px 9px',
                        marginBottom: 4,
                        whiteSpace: 'nowrap',
                        background: '#c0dd97',
                        color: '#27500a'
                      }}
                    >
                      {metricasSemanaAtual.labelTagSemana}
                    </span>
                    <div
                      style={{
                        fontSize: 20,
                        fontWeight: 500,
                        lineHeight: 1.2,
                        color: corValorGrandeEngajamento(metricasSemanaAtual.comp.pctAting)
                      }}
                    >
                      {metricasSemanaAtual.comp.atingidos} de {metricasSemanaAtual.comp.total}
                    </div>
                    <div
                      style={{
                        fontSize: 10,
                        marginTop: 2,
                        marginBottom: 3,
                        color: corValorGrandeEngajamento(metricasSemanaAtual.comp.pctAting)
                      }}
                    >
                      {metricasSemanaAtual.comp.atg?.label ?? '—'}
                    </div>
                    <BarraProgresso pct={metricasSemanaAtual.comp.pctAting} />
                  </div>

                  <div
                    style={{
                      marginTop: 10,
                      paddingTop: 10,
                      borderTop: '0.5px dashed rgba(0,0,0,0.12)',
                      width: '100%'
                    }}
                  >
                    <span
                      style={{
                        display: 'inline-block',
                        fontSize: 10,
                        fontWeight: 500,
                        borderRadius: 10,
                        padding: '2px 9px',
                        marginBottom: 4,
                        whiteSpace: 'nowrap',
                        background: '#c0dd97',
                        color: '#27500a'
                      }}
                    >
                      {labelTagPeriodoFiltro}
                    </span>
                    <div
                      style={{
                        fontSize: 20,
                        fontWeight: 500,
                        lineHeight: 1.2,
                        color: corValorGrandeEngajamento(resumoCardsVisual.pctAtingidosComp)
                      }}
                    >
                      {resumoExecutivo.compOk[0]} de {resumoExecutivo.compOk[1]}
                    </div>
                    <div
                      style={{
                        fontSize: 10,
                        marginTop: 2,
                        marginBottom: 3,
                        color: corValorGrandeEngajamento(resumoCardsVisual.pctAtingidosComp)
                      }}
                    >
                      {resumoCardsVisual.atgComp?.label ?? '—'}
                    </div>
                    <BarraProgresso pct={resumoCardsVisual.pctAtingidosComp} />
                  </div>
                </div>

                <div
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    textAlign: 'center',
                    padding: '0 6px',
                    borderLeft: '0.5px solid rgba(0,0,0,0.08)'
                  }}
                >
                  <div style={{ fontSize: 11, color: '#555', fontWeight: 500, marginBottom: 8 }}>
                    Resultado médio
                  </div>

                  <div>
                    <span
                      style={{
                        display: 'inline-block',
                        fontSize: 10,
                        fontWeight: 500,
                        borderRadius: 10,
                        padding: '2px 9px',
                        marginBottom: 4,
                        whiteSpace: 'nowrap',
                        background: '#c0dd97',
                        color: '#27500a'
                      }}
                    >
                      {metricasSemanaAtual.labelTagSemana}
                    </span>
                    <div
                      style={{
                        fontSize: 20,
                        fontWeight: 500,
                        lineHeight: 1.2,
                        color: corValorGrandeEngajamento(metricasSemanaAtual.comp.mediaPct)
                      }}
                    >
                      {metricasSemanaAtual.comp.mediaPct != null ? `${metricasSemanaAtual.comp.mediaPct}%` : '—'}
                    </div>
                    <div
                      style={{
                        fontSize: 10,
                        marginTop: 2,
                        marginBottom: 3,
                        color: corValorGrandeEngajamento(metricasSemanaAtual.comp.mediaPct)
                      }}
                    >
                      {metricasSemanaAtual.comp.rm?.label ?? '—'}
                    </div>
                    <BarraProgresso pct={metricasSemanaAtual.comp.mediaPct} />
                  </div>

                  <div
                    style={{
                      marginTop: 10,
                      paddingTop: 10,
                      borderTop: '0.5px dashed rgba(0,0,0,0.12)',
                      width: '100%'
                    }}
                  >
                    <span
                      style={{
                        display: 'inline-block',
                        fontSize: 10,
                        fontWeight: 500,
                        borderRadius: 10,
                        padding: '2px 9px',
                        marginBottom: 4,
                        whiteSpace: 'nowrap',
                        background: '#c0dd97',
                        color: '#27500a'
                      }}
                    >
                      {labelTagPeriodoFiltro}
                    </span>
                    <div
                      style={{
                        fontSize: 20,
                        fontWeight: 500,
                        lineHeight: 1.2,
                        color: corValorGrandeEngajamento(resumoCardsVisual.engajamentoMedioPct)
                      }}
                    >
                      {resumoCardsVisual.engajamentoMedioPct != null ? `${resumoCardsVisual.engajamentoMedioPct}%` : '—'}
                    </div>
                    <div
                      style={{
                        fontSize: 10,
                        marginTop: 2,
                        marginBottom: 3,
                        color: corValorGrandeEngajamento(resumoCardsVisual.engajamentoMedioPct)
                      }}
                    >
                      {resumoCardsVisual.rmComp?.label ?? '—'}
                    </div>
                    <BarraProgresso pct={resumoCardsVisual.engajamentoMedioPct} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            height: '100%',
            minHeight: 0,
            borderRadius: 8,
            overflow: 'hidden',
            border: '0.5px solid var(--ind-bdr)'
          }}
        >
          <div
            style={{
              background: 'var(--ind-dark)',
              padding: '12px 16px',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: 4
            }}
          >
            <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--hdr-text)', textAlign: 'center' }}>
              Indicadores — Resultado
            </div>
            <div style={{ fontSize: 11, color: 'var(--hdr-sub)', textAlign: 'center' }}>
              {resumoExecutivo.indAtivos} indicadores ativos no período
            </div>
          </div>
          <div
            style={{
              flex: 1,
              minHeight: 0,
              background: 'var(--ind-bg)',
              padding: 16,
              display: 'flex',
              flexDirection: 'column'
            }}
          >
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 12,
                flex: 1,
                minHeight: 0
              }}
            >
              <CarinhaBlocoResumo
                tipo="ind"
                codigo={codigoCarinhaIndicadores}
                labelColor={corLabelFaixaResultadoMedioMes(resultadoMedioMesInd)}
                imgAlt="carinha indicadores"
                carinhaVisible={carinhaVisible}
              />
              <div
                style={{
                  width: '0.5px',
                  minWidth: '0.5px',
                  alignSelf: 'stretch',
                  background: 'rgba(0, 0, 0, 0.12)',
                  margin: '0 4px',
                  flexShrink: 0
                }}
              />
              <div
                style={{
                  flex: 1,
                  display: 'grid',
                  gridTemplateColumns: '1fr 1fr',
                  gap: 0,
                  minWidth: 0
                }}
              >
                <div
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    textAlign: 'center',
                    padding: '0 6px'
                  }}
                >
                  <div style={{ fontSize: 11, color: '#555', fontWeight: 500, marginBottom: 8 }}>
                    Atingidos (≥60%)
                  </div>

                  <div>
                    <span
                      style={{
                        display: 'inline-block',
                        fontSize: 10,
                        fontWeight: 500,
                        borderRadius: 10,
                        padding: '2px 9px',
                        marginBottom: 4,
                        whiteSpace: 'nowrap',
                        background: '#b5d4f4',
                        color: '#0c447c'
                      }}
                    >
                      {metricasSemanaAtual.labelTagSemana}
                    </span>
                    <div
                      style={{
                        fontSize: 20,
                        fontWeight: 500,
                        lineHeight: 1.2,
                        color: corValorGrandeIndicador(metricasSemanaAtual.ind.pctAting)
                      }}
                    >
                      {metricasSemanaAtual.ind.atingidos} de {metricasSemanaAtual.ind.total}
                    </div>
                    <div
                      style={{
                        fontSize: 10,
                        marginTop: 2,
                        marginBottom: 3,
                        color: corValorGrandeIndicador(metricasSemanaAtual.ind.pctAting)
                      }}
                    >
                      {metricasSemanaAtual.ind.atg?.label ?? '—'}
                    </div>
                    <BarraProgresso pct={metricasSemanaAtual.ind.pctAting} />
                  </div>

                  <div
                    style={{
                      marginTop: 10,
                      paddingTop: 10,
                      borderTop: '0.5px dashed rgba(0,0,0,0.12)',
                      width: '100%'
                    }}
                  >
                    <span
                      style={{
                        display: 'inline-block',
                        fontSize: 10,
                        fontWeight: 500,
                        borderRadius: 10,
                        padding: '2px 9px',
                        marginBottom: 4,
                        whiteSpace: 'nowrap',
                        background: 'var(--surf2)',
                        color: 'var(--moni-texto-suave)'
                      }}
                    >
                      {labelTagPeriodoFiltro}
                    </span>
                    <div
                      style={{
                        fontSize: 20,
                        fontWeight: 500,
                        lineHeight: 1.2,
                        color: corValorGrandeIndicador(resumoCardsVisual.pctAtingidosInd)
                      }}
                    >
                      {resumoExecutivo.indAtingidos[0]} de {resumoExecutivo.indAtingidos[1]}
                    </div>
                    <div
                      style={{
                        fontSize: 10,
                        marginTop: 2,
                        marginBottom: 3,
                        color: corValorGrandeIndicador(resumoCardsVisual.pctAtingidosInd)
                      }}
                    >
                      {resumoCardsVisual.atgInd?.label ?? '—'}
                    </div>
                    <BarraProgresso pct={resumoCardsVisual.pctAtingidosInd} />
                  </div>
              </div>

                <div
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    textAlign: 'center',
                    padding: '0 6px',
                    borderLeft: '0.5px solid rgba(0,0,0,0.08)'
                  }}
                >
                  <div style={{ fontSize: 11, color: '#555', fontWeight: 500, marginBottom: 8 }}>
                    Resultado médio
                  </div>

                  <div>
                    <span
                      style={{
                        display: 'inline-block',
                        fontSize: 10,
                        fontWeight: 500,
                        borderRadius: 10,
                        padding: '2px 9px',
                        marginBottom: 4,
                        whiteSpace: 'nowrap',
                        background: '#b5d4f4',
                        color: '#0c447c'
                      }}
                    >
                      {metricasSemanaAtual.labelTagSemana}
                    </span>
                    <div
                      style={{
                        fontSize: 20,
                        fontWeight: 500,
                        lineHeight: 1.2,
                        color: corValorGrandeIndicador(metricasSemanaAtual.ind.mediaPct)
                      }}
                    >
                      {metricasSemanaAtual.ind.mediaPct != null ? `${metricasSemanaAtual.ind.mediaPct}%` : '—'}
                    </div>
                    <div
                      style={{
                        fontSize: 10,
                        marginTop: 2,
                        marginBottom: 3,
                        color: corValorGrandeIndicador(metricasSemanaAtual.ind.mediaPct)
                      }}
                    >
                      {metricasSemanaAtual.ind.rm?.label ?? '—'}
                    </div>
                    <BarraProgresso pct={metricasSemanaAtual.ind.mediaPct} />
                  </div>

                  <div
                    style={{
                      marginTop: 10,
                      paddingTop: 10,
                      borderTop: '0.5px dashed rgba(0,0,0,0.12)',
                      width: '100%'
                    }}
                  >
                    <span
                      style={{
                        display: 'inline-block',
                        fontSize: 10,
                        fontWeight: 500,
                        borderRadius: 10,
                        padding: '2px 9px',
                        marginBottom: 4,
                        whiteSpace: 'nowrap',
                        background: '#b5d4f4',
                        color: '#0c447c'
                      }}
                    >
                      {labelTagPeriodoFiltro}
                    </span>
                    <div
                      style={{
                        fontSize: 20,
                        fontWeight: 500,
                        lineHeight: 1.2,
                        color: corValorGrandeIndicador(resumoCardsVisual.indicadorMedioPct)
                      }}
                    >
                      {resumoCardsVisual.indicadorMedioPct != null ? `${resumoCardsVisual.indicadorMedioPct}%` : '—'}
                    </div>
                    <div
                      style={{
                        fontSize: 10,
                        marginTop: 2,
                        marginBottom: 3,
                        color: corValorGrandeIndicador(resumoCardsVisual.indicadorMedioPct)
                      }}
                    >
                      {resumoCardsVisual.rmInd?.label ?? '—'}
                    </div>
                    <BarraProgresso pct={resumoCardsVisual.indicadorMedioPct} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 12,
          flexWrap: 'wrap',
          marginBottom: 10,
          fontSize: 12,
          color: 'var(--moni-texto-suave)'
        }}
      >
        <span style={{ fontWeight: 500, color: 'var(--moni-texto)' }}>Comportamento e Indicador:</span>
        {[
          { bg: '#2e7d32', fg: '#fff', label: '≥75%' },
          { bg: '#8bc34a', fg: '#fff', label: '60–74%' },
          { bg: '#e6a817', fg: '#fff', label: '30–59%' },
          { bg: '#e74c3c', fg: '#fff', label: '<30%' },
          { empty: true, label: 'Sem dado' }
        ].map(item =>
          item.empty ? (
            <SemBadge key={item.label} variant="legend" empty>
              {item.label}
            </SemBadge>
          ) : (
            <SemBadge key={item.label} variant="legend" style={{ background: item.bg, color: item.fg }}>
              {item.label}
            </SemBadge>
          )
        )}
        <span
          style={{
            marginLeft: 8,
            background: 'var(--comp-bg)',
            padding: '2px 8px',
            borderRadius: 4,
            border: '0.5px solid var(--comp-bdr)',
            color: 'var(--comp-text)',
            fontSize: 11
          }}
        >
          ★ Semana atual
        </span>
      </div>

      {loading ? (
        <p>Carregando…</p>
      ) : !selecao || semanasOrdenadas.length === 0 ? (
        <p className="empty-state">Selecione um período com datas válidas.</p>
      ) : semanasVisiveis.length === 0 ? (
        <p className="empty-state">Não há semanas ISO neste período para exibir.</p>
      ) : dadosProcessados.length === 0 ? (
        <p className="empty-state">Nenhum dado para os filtros atuais.</p>
      ) : (
        <div style={{ width: '100%', overflowX: 'auto', borderRadius: 12 }}>
          <table
            className="carometro-scorecard-table"
            style={{
              tableLayout: 'fixed',
              width: '100%',
              minWidth: 200 + 38 + 70 + 52 * semanasVisiveis.length + 96,
              borderCollapse: 'separate',
              borderSpacing: 0,
              border: '0.5px solid rgba(0,0,0,0.12)',
              borderRadius: 12,
              overflow: 'hidden',
              background: 'var(--surf0)',
              fontSize: 12
            }}
          >
            <colgroup>
              <col style={{ width: 200 }} />
              <col style={{ width: 38 }} />
              <col style={{ width: 70 }} />
              {semanasVisiveis.map(s => (
                <col key={s} style={{ width: 52 }} />
              ))}
              <col style={{ width: 96 }} />
            </colgroup>
            <thead>
              <tr style={{ background: 'var(--comp-mid)', color: 'var(--hdr-text)' }}>
                <th
                  style={{
                    padding: '10px 8px',
                    textAlign: 'left',
                    fontSize: 11,
                    fontWeight: 600,
                    borderBottom: '0.5px solid rgba(255,255,255,0.12)',
                    whiteSpace: 'nowrap'
                  }}
                >
                  Comportamento / Indicador
                </th>
                <th
                  style={{
                    padding: '8px 2px',
                    textAlign: 'center',
                    fontSize: 10,
                    fontWeight: 600,
                    borderBottom: '0.5px solid rgba(255,255,255,0.12)',
                    whiteSpace: 'nowrap'
                  }}
                >
                  Chave
                </th>
                <th
                  style={{
                    padding: '10px 4px',
                    textAlign: 'center',
                    fontSize: 11,
                    fontWeight: 600,
                    borderBottom: '0.5px solid rgba(255,255,255,0.12)',
                    whiteSpace: 'nowrap'
                  }}
                >
                  Responsável
                </th>
                {semanasVisiveis.map(w => {
                  const dest = w === semanaColunaDestaque
                  return (
                    <th
                      key={w}
                      style={{
                        padding: '8px 2px',
                        textAlign: 'center',
                        fontSize: 10,
                        fontWeight: 600,
                        borderBottom: '0.5px solid rgba(255,255,255,0.12)',
                        background: dest ? 'var(--comp-med)' : 'var(--comp-mid)',
                        color: 'var(--hdr-text)',
                        whiteSpace: 'nowrap'
                      }}
                    >
                      S{w}
                      {dest ? ' ★' : ''}
                      <span
                        style={{
                          fontSize: 9,
                          fontWeight: 400,
                          color: 'var(--hdr-sub)',
                          display: 'block',
                          marginTop: 1,
                          letterSpacing: 0,
                          textTransform: 'none'
                        }}
                      >
                        {getDatasSemanaCurta(w, anoDatasSemana)}
                      </span>
                    </th>
                  )
                })}
                <th
                  style={{
                    padding: '8px 4px',
                    textAlign: 'center',
                    fontSize: 10,
                    fontWeight: 600,
                    borderBottom: '0.5px solid rgba(255,255,255,0.12)',
                    whiteSpace: 'nowrap'
                  }}
                >
                  Status
                </th>
              </tr>
            </thead>
            <tbody>
              {dadosProcessados.map(block => (
                <Fragment key={block.area.id}>
                  <tr
                    className="carometro-row--area"
                    style={{ background: 'var(--comp-dark)', color: 'var(--hdr-text)', cursor: 'default', fontWeight: 600 }}
                  >
                    <td
                      colSpan={4 + semanasVisiveis.length}
                      style={{
                        background: 'var(--comp-dark)',
                        padding: '10px 12px',
                        fontWeight: 600,
                        textTransform: 'uppercase',
                        letterSpacing: '0.05em',
                        fontSize: 12,
                        borderBottom: '0.5px solid rgba(255,255,255,0.12)',
                        whiteSpace: 'nowrap',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis'
                      }}
                    >
                      {block.area.nome}
                    </td>
                  </tr>
                  {block.metas.map(meta => (
                    <Fragment key={meta.id}>
                      <tr
                        className="carometro-row--meta"
                        style={{ background: 'var(--comp-dark)', color: 'var(--hdr-text)', cursor: 'default', fontWeight: 600 }}
                      >
                        <td
                          style={{
                            background: 'var(--comp-dark)',
                            padding: '10px 10px',
                            verticalAlign: 'middle',
                            borderBottom: '0.5px solid rgba(255,255,255,0.1)',
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis'
                          }}
                        >
                          <div style={{ fontWeight: 600, fontSize: 12 }}>{meta.descricao}</div>
                          {meta.prazo && (
                            <div style={{ fontSize: 11, color: 'var(--hdr-sub)', marginTop: 4 }}>Prazo {meta.prazo}</div>
                          )}
                        </td>
                        <td style={{ background: 'var(--comp-dark)', borderBottom: '0.5px solid rgba(255,255,255,0.1)' }} />
                        <td style={{ background: 'var(--comp-dark)', borderBottom: '0.5px solid rgba(255,255,255,0.1)' }} />
                        {semanasVisiveis.map(w => (
                          <td
                            key={w}
                            style={{ borderBottom: '0.5px solid rgba(255,255,255,0.1)', background: 'var(--comp-dark)' }}
                          />
                        ))}
                        <td style={{ background: 'var(--comp-dark)', borderBottom: '0.5px solid rgba(255,255,255,0.1)' }} />
                      </tr>
                      {meta.comportamentos.map(c => (
                        <tr key={c.id} className="carometro-row--comp" style={{ background: '#fff' }}>
                          <td
                            style={{
                              padding: '8px 10px',
                              borderBottom: '0.5px solid rgba(0,0,0,0.08)',
                              verticalAlign: 'middle',
                              whiteSpace: 'nowrap',
                              overflow: 'hidden',
                              textOverflow: 'ellipsis',
                              fontSize: 12
                            }}
                          >
                            <div style={{ display: 'flex', alignItems: 'center', gap: 3, overflow: 'hidden' }}>
                              <span className="chip-comp">Comp.</span>
                              <span
                                style={{
                                  overflow: 'hidden',
                                  textOverflow: 'ellipsis',
                                  whiteSpace: 'nowrap',
                                  fontSize: 11,
                                  color: 'var(--moni-texto)'
                                }}
                              >
                                {c.nome}
                              </span>
                            </div>
                          </td>
                          <td
                            style={{
                              textAlign: 'center',
                              borderBottom: '0.5px solid rgba(0,0,0,0.08)',
                              verticalAlign: 'middle'
                            }}
                          >
                            <input
                              type="checkbox"
                              checked={!!c.isChave}
                              disabled={!isAdmin || salvandoChave === `t-${c.id}`}
                              onChange={() =>
                                toggleChaveTarefa({ id: c.id, is_chave: c.isChave })
                              }
                              title={
                                isAdmin
                                  ? 'Comportamento chave (caneta verde nas ações)'
                                  : 'Somente administradores podem alterar'
                              }
                              style={{
                                width: 12,
                                height: 12,
                                cursor: isAdmin ? 'pointer' : 'not-allowed',
                                accentColor: 'var(--comp-light)'
                              }}
                            />
                          </td>
                          <td
                            style={{
                              textAlign: 'center',
                              fontSize: 12,
                              borderBottom: '0.5px solid rgba(0,0,0,0.08)',
                              verticalAlign: 'middle',
                              color: 'var(--moni-texto)',
                              whiteSpace: 'nowrap',
                              overflow: 'hidden',
                              textOverflow: 'ellipsis'
                            }}
                          >
                            {c.responsavel}
                          </td>
                          {semanasVisiveis.map(w => (
                            <td
                              key={w}
                              style={{
                                borderBottom: '0.5px solid rgba(0,0,0,0.08)',
                                verticalAlign: 'middle',
                                background: w === semanaColunaDestaque ? 'var(--comp-bg)' : undefined,
                                whiteSpace: 'nowrap',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis'
                              }}
                            >
                              <CelulaSemanaComportamento
                                cod={c.semanas[Number(w)] ?? 'ena'}
                                pct={c.pctSemanas?.[Number(w)]}
                                comentarioTooltip={textoComentarioComportamentoCar(c.id, w)}
                              />
                            </td>
                          ))}
                          <td
                            style={{
                              textAlign: 'center',
                              borderBottom: '0.5px solid rgba(0,0,0,0.08)',
                              verticalAlign: 'middle'
                            }}
                          >
                            <PillStatusComportamento
                              cod={statusConsolidadoComportamento(
                                c.pctSemanas || {},
                                semanasVisiveis,
                                c.pctPeriodo
                              )}
                              pctMedia={
                                c.pctPeriodo != null && !Number.isNaN(c.pctPeriodo)
                                  ? c.pctPeriodo
                                  : mediaPctComportamento(c.pctSemanas || {}, semanasVisiveis)
                              }
                            />
                          </td>
                        </tr>
                      ))}
                      {meta.indicadores.map(ind => (
                        <tr
                          key={ind.id}
                          className="carometro-row--ind"
                          style={{
                            background: 'var(--ind-bg)',
                            color: 'var(--ind-text)',
                            borderBottom: '0.5px solid var(--ind-bdr)'
                          }}
                        >
                          <td
                            style={{
                              padding: '8px 10px',
                              borderBottom: '0.5px solid var(--ind-bdr)',
                              verticalAlign: 'middle',
                              whiteSpace: 'nowrap',
                              overflow: 'hidden',
                              textOverflow: 'ellipsis',
                              fontSize: 12
                            }}
                          >
                            <div style={{ display: 'flex', alignItems: 'center', gap: 3, overflow: 'hidden' }}>
                              <span className="chip-ind">Ind.</span>
                              <span
                                style={{
                                  overflow: 'hidden',
                                  textOverflow: 'ellipsis',
                                  whiteSpace: 'nowrap',
                                  fontSize: 11,
                                  fontStyle: 'italic'
                                }}
                              >
                                {ind.nome}
                              </span>
                            </div>
                          </td>
                          <td
                            style={{
                              textAlign: 'center',
                              borderBottom: '0.5px solid var(--ind-bdr)',
                              verticalAlign: 'middle'
                            }}
                          >
                            <input
                              type="checkbox"
                              checked={!!ind.isChave}
                              disabled={!isAdmin || salvandoChave === `i-${ind.id}`}
                              onChange={() => toggleChaveIndicador(ind)}
                              title={isAdmin ? 'Indicador chave' : 'Somente administradores'}
                              style={{
                                width: 12,
                                height: 12,
                                cursor: isAdmin ? 'pointer' : 'not-allowed',
                                accentColor: 'var(--ind-light)'
                              }}
                            />
                          </td>
                          <td
                            style={{
                              textAlign: 'center',
                              fontSize: 12,
                              borderBottom: '0.5px solid var(--ind-bdr)',
                              verticalAlign: 'middle',
                              whiteSpace: 'nowrap'
                            }}
                          >
                            —
                          </td>
                          {semanasVisiveis.map(w => (
                            <td
                              key={w}
                              style={{
                                borderBottom: '0.5px solid var(--ind-bdr)',
                                textAlign: 'center',
                                verticalAlign: 'middle',
                                background: w === semanaColunaDestaque ? '#d4e6f0' : 'var(--ind-bg)',
                                whiteSpace: 'nowrap',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis'
                              }}
                            >
                              <CelulaIndicadorSemana
                                cod={ind.semanas[Number(w)] ?? 'ina'}
                                valor={ind.valorSemanas?.[Number(w)]}
                                comentarioTooltip={textoComentarioIndicadorCar(ind.id, w)}
                              />
                            </td>
                          ))}
                          <td
                            style={{
                              textAlign: 'center',
                              borderBottom: '0.5px solid var(--ind-bdr)',
                              verticalAlign: 'middle'
                            }}
                          >
                            <PillStatusIndicador
                              cod={statusUltimoIndicador(ind.semanas || {}, semanasVisiveis)}
                              pctMedia={mediaPctIndicador(ind.semanas || {}, semanasVisiveis)}
                            />
                          </td>
                        </tr>
                      ))}
                    </Fragment>
                  ))}
                </Fragment>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
