import { useCallback, useEffect, useMemo, useRef, useState, Fragment } from 'react'
import { supabase } from '../services/supabase'
import PeriodoSelect from '../components/PeriodoSelect'

const NOMES_AREAS_ALVO = ['Produto', 'Projetos - Modelo Virtual']

const PALETA_CASAS = [
  { bg: '#E6F1FB', border: '#B5D4F4' },
  { bg: '#F3EEFE', border: '#AFA9EC' },
  { bg: '#FEF3E6', border: '#EF9F27' },
  { bg: '#E6FBF3', border: '#1D9E75' },
  { bg: '#FEE6E6', border: '#E24B4A' },
  { bg: '#F3F3FE', border: '#7F77DD' },
  { bg: '#FEFCE6', border: '#BA7517' },
  { bg: '#F1EFE8', border: '#888780' }
]

function getCorCasa(index) {
  return PALETA_CASAS[index % PALETA_CASAS.length]
}

function getCorProgresso(pct) {
  if (pct === null) return { text: 'var(--color-text-secondary)', bar: '#D3D1C7' }
  if (pct === 100) return { text: '#0A5C38', bar: '#0F7A4A' }
  if (pct >= 75) return { text: '#2A5A00', bar: '#5A9A1A' }
  if (pct >= 50) return { text: '#7A4200', bar: '#C07800' }
  return { text: '#8B1A1A', bar: '#B01A1A' }
}

function statusCronogramaConcluido(status) {
  const x = String(status ?? '')
    .toLowerCase()
    .trim()
  return (
    x === 'concluido' ||
    x === 'concluído' ||
    x === 'realizado' ||
    x === 'feito' ||
    x === 'done' ||
    x === 'completo' ||
    x === 'finalizado'
  )
}

/**
 * % por tarefa/casa: concluídas (via gantt mais recente da casa) ÷ total de ações da tarefa.
 * Replanejamento: só conta conclusão ligada ao `gantt_planejamento` mais recente da ação naquela casa.
 * @returns {{ pct: number | null, concluidas: number, total: number }}
 */
function medirProgressoTarefaCasa(tarefaId, casaGroup, acoes, cronograma, ganttPlanejamento) {
  const acoesDaTarefa = acoes.filter(a => a.tarefa_id === tarefaId)
  const total = acoesDaTarefa.length
  if (total === 0) return { pct: null, concluidas: 0, total: 0 }

  const idsSet = new Set((casaGroup.ids || []).filter(Boolean).map(String))
  const acaoIdsSet = new Set(acoesDaTarefa.map(a => String(a.id)))

  const ganttDaCasa = (ganttPlanejamento || []).filter(g => {
    if (!acaoIdsSet.has(String(g.acao_id))) return false
    if (!g.casa_id) return false
    return idsSet.has(String(g.casa_id))
  })

  if (ganttDaCasa.length === 0) return { pct: null, concluidas: 0, total }

  const ganttMaisRecentePorAcao = {}
  for (const g of ganttDaCasa) {
    const aid = String(g.acao_id)
    const atual = ganttMaisRecentePorAcao[aid]
    if (!atual) {
      ganttMaisRecentePorAcao[aid] = g
    } else {
      const semAtual = Number(atual.semana_ano_inicio ?? 0)
      const semNova = Number(g.semana_ano_inicio ?? 0)
      if (semNova > semAtual) {
        ganttMaisRecentePorAcao[aid] = g
      } else if (semNova === semAtual) {
        const tAtual = atual.criado_em ? new Date(atual.criado_em).getTime() : 0
        const tNova = g.criado_em ? new Date(g.criado_em).getTime() : 0
        if (tNova > tAtual) ganttMaisRecentePorAcao[aid] = g
      }
    }
  }

  const planejamentosRecentesIds = new Set(Object.values(ganttMaisRecentePorAcao).map(g => String(g.id)))

  const acoesConcluidasSet = new Set()

  for (const c of cronograma || []) {
    if (!acaoIdsSet.has(String(c.acao_id))) continue
    if (!statusCronogramaConcluido(c.status)) continue

    const pid = c?.planejamento_id
    if (pid && planejamentosRecentesIds.has(String(pid))) {
      acoesConcluidasSet.add(String(c.acao_id))
    } else if (!pid) {
      const temVinculo = (cronograma || []).some(
        x =>
          String(x.acao_id) === String(c.acao_id) &&
          x.planejamento_id &&
          planejamentosRecentesIds.has(String(x.planejamento_id))
      )
      if (!temVinculo && ganttMaisRecentePorAcao[String(c.acao_id)]) {
        acoesConcluidasSet.add(String(c.acao_id))
      }
    }
  }

  const n = acoesConcluidasSet.size
  const pct = Math.min(100, Math.round((n / total) * 100))
  return { pct: n === 0 && ganttDaCasa.length === 0 ? null : pct, concluidas: n, total }
}

function agruparCasasPorNome(todasCasas) {
  const casasAgrupadas = []
  const nomesSeen = {}
  for (const casa of todasCasas || []) {
    const nomeNorm = String(casa.nome ?? '')
      .trim()
      .toLowerCase()
    if (!nomeNorm) continue
    if (nomesSeen[nomeNorm] !== undefined) {
      casasAgrupadas[nomesSeen[nomeNorm]].ids.push(casa.id)
    } else {
      nomesSeen[nomeNorm] = casasAgrupadas.length
      casasAgrupadas.push({
        nome: String(casa.nome).trim() || casa.nome,
        ids: [casa.id]
      })
    }
  }
  return casasAgrupadas
}

async function carregarCronogramaDashboard(periodoId, _periodoDb, acaoIds) {
  if (!periodoId || acaoIds.length === 0)
    return { cronograma: [], ganttPlanejamento: [], loadMeta: { cronCount: 0, ganttCount: 0 } }

  const acaoIdsArr = [...new Set(acaoIds.map(String).filter(Boolean))]

  const { data: ganttData, error: errG } = await supabase
    .from('gantt_planejamento')
    .select(
      'id, acao_id, casa_id, periodo_id, semanas_selecionadas, semana_inicio, semana_fim, semana_ano_inicio, semana_ano_fim, criado_em'
    )
    .eq('periodo_id', periodoId)
    .in('acao_id', acaoIdsArr)

  const { data: cronData, error: errC } = await supabase
    .from('cronograma')
    .select('id, acao_id, status, planejamento_id, semana, semana_ano, periodo_id, horas_previstas')
    .eq('periodo_id', periodoId)
    .in('acao_id', acaoIdsArr)

  let cronRows = cronData || []
  const ganttRows = ganttData || []

  if (cronRows.length === 0 && ganttRows.length > 0) {
    const ganttIds = ganttRows.map(g => g.id).filter(Boolean)
    const { data: cronFallback } = await supabase
      .from('cronograma')
      .select('id, acao_id, status, planejamento_id, semana, semana_ano, periodo_id, horas_previstas')
      .in('planejamento_id', ganttIds)
    cronRows = cronFallback || []
  }

  return {
    cronograma: cronRows,
    ganttPlanejamento: ganttRows,
    loadMeta: {
      cronCount: cronRows.length,
      ganttCount: ganttRows.length,
      errCron: errC?.message || null,
      errGantt: errG?.message || null
    }
  }
}

export default function DashboardProdutos() {
  const [periodoId, setPeriodoId] = useState(null)
  const [periodoDb, setPeriodoDb] = useState(null)

  const [areasAlvo, setAreasAlvo] = useState([])
  const [areasMetaLoaded, setAreasMetaLoaded] = useState(false)
  const [filtroArea, setFiltroArea] = useState('ambos')
  /** Filtro por nome exibido da casa agrupada; vazio = todas */
  const [casaFiltro, setCasaFiltro] = useState('')

  const filtrosRef = useRef(null)
  const [filtrosOpen, setFiltrosOpen] = useState(false)

  const [casas, setCasas] = useState([])
  const [tarefas, setTarefas] = useState([])
  const [acoes, setAcoes] = useState([])
  const [dashData, setDashData] = useState({ cronograma: [], ganttPlanejamento: [] })
  /** Contagens/erros da última carga (para você conferir com o Supabase sem adivinhar). */
  const [dashLoadInfo, setDashLoadInfo] = useState(null)

  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    if (!filtrosOpen) return
    function handler(e) {
      if (filtrosRef.current && !filtrosRef.current.contains(e.target)) {
        setFiltrosOpen(false)
      }
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [filtrosOpen])

  const filtrosAtivos = useMemo(() => {
    const f = []
    if (casaFiltro) f.push({ label: casaFiltro, onRemove: () => setCasaFiltro('') })
    if (filtroArea !== 'ambos') {
      const label = filtroArea === 'produto' ? 'Produto' : 'Projetos'
      f.push({ label, onRemove: () => setFiltroArea('ambos') })
    }
    return f
  }, [casaFiltro, filtroArea])

  const areaIdsFiltrados = useMemo(() => {
    const byNome = {}
    areasAlvo.forEach(a => {
      byNome[a.nome] = a.id
    })
    if (filtroArea === 'ambos') return areasAlvo.map(a => a.id).filter(Boolean)
    if (filtroArea === 'produto') return byNome['Produto'] ? [byNome['Produto']] : []
    if (filtroArea === 'projetos') return byNome['Projetos - Modelo Virtual'] ? [byNome['Projetos - Modelo Virtual']] : []
    return []
  }, [areasAlvo, filtroArea])

  const areasOrdenadasExibicao = useMemo(() => {
    const order = ['Produto', 'Projetos - Modelo Virtual']
    return order
      .map(nome => areasAlvo.find(a => a.nome === nome))
      .filter(Boolean)
      .filter(a => areaIdsFiltrados.includes(a.id))
  }, [areasAlvo, areaIdsFiltrados])

  const casasAgrupadas = useMemo(() => {
    const todasCasas = casas.filter(c => areaIdsFiltrados.includes(c.area_id))
    return agruparCasasPorNome(todasCasas)
  }, [casas, areaIdsFiltrados])

  const casasVisiveis = useMemo(() => {
    if (!casaFiltro) return casasAgrupadas
    return casasAgrupadas.filter(cg => cg.nome === casaFiltro)
  }, [casasAgrupadas, casaFiltro])

  const tarefasVisiveis = useMemo(
    () => tarefas.filter(t => areaIdsFiltrados.includes(t.area_id)),
    [tarefas, areaIdsFiltrados]
  )

  const tarefasComGantt = useMemo(() => {
    if (dashData.ganttPlanejamento.length === 0) return tarefasVisiveis
    const acaoIdsComGantt = new Set(
      dashData.ganttPlanejamento.filter(g => g.casa_id != null).map(g => String(g.acao_id))
    )
    return tarefasVisiveis.filter(t =>
      acoes.some(a => a.tarefa_id === t.id && acaoIdsComGantt.has(String(a.id)))
    )
  }, [tarefasVisiveis, dashData.ganttPlanejamento, acoes])

  const totalAtividades = useMemo(
    () =>
      tarefasComGantt.reduce((sum, t) => sum + acoes.filter(a => a.tarefa_id === t.id).length, 0),
    [tarefasComGantt, acoes]
  )

  useEffect(() => {
    let cancel = false
    ;(async () => {
      const { data, error: err } = await supabase.from('areas').select('id, nome').in('nome', NOMES_AREAS_ALVO)
      if (cancel) return
      if (err) {
        setError(err.message)
        setAreasAlvo([])
        setAreasMetaLoaded(true)
        return
      }
      setAreasAlvo(data || [])
      setAreasMetaLoaded(true)
    })()
    return () => {
      cancel = true
    }
  }, [])

  // Define um período padrão (trimestre) ao abrir a aba, para carregar dados automaticamente.
  useEffect(() => {
    let cancel = false
    ;(async () => {
      if (periodoId) return
      const hoje = new Date()
      const hojeIso = hoje.toISOString().slice(0, 10)
      const anoAtual = hoje.getFullYear()
      try {
        // 1) Trimestre que contém a data de hoje
        const { data } = await supabase
          .from('periodos')
          .select('id, tipo, numero, ano, data_inicio, data_fim')
          .eq('tipo', 'trimestre')
          .lte('data_inicio', hojeIso)
          .gte('data_fim', hojeIso)
          .maybeSingle()
        if (cancel) return
        if (data?.id) {
          setPeriodoId(data.id)
          return
        }
        // 2) Fallback: trimestre mais recente do ano atual
        const { data: fallback } = await supabase
          .from('periodos')
          .select('id, tipo, numero, ano, data_inicio, data_fim')
          .eq('tipo', 'trimestre')
          .eq('ano', anoAtual)
          .order('numero', { ascending: false })
          .limit(1)
          .maybeSingle()
        if (cancel) return
        if (fallback?.id) setPeriodoId(fallback.id)
      } catch {
        // Sem período padrão → mantém vazio; usuário pode escolher no filtro.
      }
    })()
    return () => {
      cancel = true
    }
  }, [periodoId])

  useEffect(() => {
    let cancel = false
    ;(async () => {
      if (!areasMetaLoaded) return
      if (areaIdsFiltrados.length === 0) {
        setCasas([])
        setTarefas([])
        setAcoes([])
        setDashData({ cronograma: [], ganttPlanejamento: [] })
        setDashLoadInfo(null)
        setLoading(false)
        return
      }
      setLoading(true)
      setError(null)
      try {
        const { data: casasRows, error: errCasas } = await supabase
          .from('casas')
          .select('id, nome, area_id')
          .in('area_id', areaIdsFiltrados)
          .order('criado_em', { ascending: true })
        if (errCasas) throw errCasas

        const { data: tarefasRows, error: errTar } = await supabase
          .from('tarefas')
          .select('id, nome, area_id')
          .in('area_id', areaIdsFiltrados)
          .order('ordem', { ascending: true })
        if (errTar) throw errTar

        const tIds = (tarefasRows || []).map(t => t.id).filter(Boolean)
        let acoesRows = []
        if (tIds.length > 0) {
          const { data: ar, error: errA } = await supabase
            .from('acoes')
            .select('id, nome, tarefa_id')
            .in('tarefa_id', tIds)
          if (errA) throw errA
          acoesRows = ar || []
        }

        if (cancel) return
        setCasas(casasRows || [])
        setTarefas(tarefasRows || [])
        setAcoes(acoesRows)
      } catch (e) {
        if (!cancel) setError(e?.message || String(e))
      } finally {
        if (!cancel) setLoading(false)
      }
    })()
    return () => {
      cancel = true
    }
  }, [areasMetaLoaded, areaIdsFiltrados])

  useEffect(() => {
    if (casaFiltro && !casasAgrupadas.some(cg => cg.nome === casaFiltro)) {
      setCasaFiltro('')
    }
  }, [casasAgrupadas, casaFiltro])

  useEffect(() => {
    let cancel = false
    ;(async () => {
      if (!periodoId) {
        setPeriodoDb(null)
        return
      }
      const { data, error: err } = await supabase
        .from('periodos')
        .select('id, data_inicio, data_fim, tipo, ano, numero')
        .eq('id', periodoId)
        .single()
      if (cancel) return
      if (err || !data) setPeriodoDb(null)
      else setPeriodoDb(data)
    })()
    return () => {
      cancel = true
    }
  }, [periodoId])

  const recarregarCronograma = useCallback(async () => {
    const acaoIds = [...new Set(acoes.map(a => a.id).filter(Boolean))]
    if (!periodoId || acaoIds.length === 0) {
      setDashData({ cronograma: [], ganttPlanejamento: [] })
      setDashLoadInfo(null)
      return
    }
    try {
      const { cronograma: rows, ganttPlanejamento: ganttRows, loadMeta } = await carregarCronogramaDashboard(
        periodoId,
        periodoDb,
        acaoIds
      )
      setDashData({ cronograma: rows, ganttPlanejamento: ganttRows || [] })
      setDashLoadInfo(loadMeta || null)
    } catch (e) {
      setError(e?.message || String(e))
      setDashData({ cronograma: [], ganttPlanejamento: [] })
      setDashLoadInfo(null)
    }
  }, [periodoId, periodoDb, acoes])

  useEffect(() => {
    recarregarCronograma()
  }, [recarregarCronograma])

  const onPeriodoChange = id => {
    setPeriodoId(id || null)
  }

  return (
    <>
      <h1>Dashboard Casas Moní</h1>
      <p style={{ color: 'var(--color-text-secondary)', marginBottom: '1.25rem', maxWidth: '720px' }}>
        Evolução dos comportamentos por casa — Produto e Projetos - Modelo Virtual
      </p>

      {error && <div className="alert alert-error">{error}</div>}

      <div ref={filtrosRef} style={{ position: 'relative', marginBottom: '1rem' }}>
        {/* Botão Filtros */}
        <button
          type="button"
          onClick={() => setFiltrosOpen(v => !v)}
          style={{
            display: 'inline-flex', alignItems: 'center', gap: 8,
            padding: '7px 14px', borderRadius: 8, cursor: 'pointer',
            background: filtrosOpen ? '#2d4a1e' : '#3a5c28',
            color: '#C8E6A0', border: 'none', fontSize: 13, fontWeight: 500
          }}
        >
          <span style={{ fontSize: 14 }}>≡</span>
          Filtros
          {filtrosAtivos.length > 0 && (
            <span style={{
              background: '#C8E6A0', color: '#1a2e1a', borderRadius: 10,
              fontSize: 11, fontWeight: 700, padding: '1px 6px', minWidth: 18,
              textAlign: 'center'
            }}>
              {filtrosAtivos.length}
            </span>
          )}
        </button>

        {/* Chips de filtros ativos */}
        {filtrosAtivos.length > 0 && (
          <div style={{ display: 'inline-flex', gap: 6, marginLeft: 10, flexWrap: 'wrap', alignItems: 'center' }}>
            {filtrosAtivos.map(f => (
              <span
                key={f.label}
                style={{
                  display: 'inline-flex', alignItems: 'center', gap: 4,
                  background: '#e8f0e0', border: '1px solid #8fba6a',
                  borderRadius: 12, padding: '2px 8px', fontSize: 11,
                  color: '#2d4a1e', cursor: 'pointer'
                }}
                onClick={f.onRemove}
              >
                {f.label} ×
              </span>
            ))}
          </div>
        )}

        {/* Painel dropdown */}
        {filtrosOpen && (
          <div style={{
            position: 'absolute', top: '110%', left: 0, zIndex: 200,
            background: 'var(--color-background-primary)',
            border: '1px solid var(--color-border-secondary)',
            borderRadius: 10, boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
            padding: '1rem', minWidth: 320, maxHeight: '80vh', overflowY: 'auto'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <span style={{ fontSize: 13, fontWeight: 600 }}>Filtros</span>
              <button
                type="button"
                onClick={() => { setCasaFiltro(''); setFiltroArea('ambos') }}
                style={{ fontSize: 11, color: '#3a5c28', background: 'none',
                         border: 'none', cursor: 'pointer', textDecoration: 'underline' }}
              >
                Limpar tudo
              </button>
            </div>

            {/* Período */}
            <div style={{ marginBottom: 16 }}>
              <div style={{ fontSize: 10, fontWeight: 600, textTransform: 'uppercase',
                            letterSpacing: '0.05em', color: 'var(--color-text-secondary)',
                            marginBottom: 8 }}>
                Período
              </div>
              <PeriodoSelect
                value={periodoId}
                onChange={onPeriodoChange}
                defaultTipo="trimestre"
              />
            </div>

            {/* Casa */}
            <div style={{ marginBottom: 16 }}>
              <div style={{ fontSize: 10, fontWeight: 600, textTransform: 'uppercase',
                            letterSpacing: '0.05em', color: 'var(--color-text-secondary)',
                            marginBottom: 8 }}>
                Casa
              </div>
              <select
                value={casaFiltro}
                onChange={e => setCasaFiltro(e.target.value)}
                style={{ width: '100%', fontSize: 13, padding: '5px 8px',
                         borderRadius: 6, border: '1px solid var(--color-border-secondary)',
                         background: 'var(--color-background-primary)' }}
              >
                <option value="">Todas as casas</option>
                {casasAgrupadas.map(cg => (
                  <option key={cg.nome} value={cg.nome}>{cg.nome}</option>
                ))}
              </select>
            </div>

            {/* Área */}
            <div style={{ marginBottom: 8 }}>
              <div style={{ fontSize: 10, fontWeight: 600, textTransform: 'uppercase',
                            letterSpacing: '0.05em', color: 'var(--color-text-secondary)',
                            marginBottom: 8 }}>
                Área
              </div>
              <select
                value={filtroArea}
                onChange={e => setFiltroArea(e.target.value)}
                style={{ width: '100%', fontSize: 13, padding: '5px 8px',
                         borderRadius: 6, border: '1px solid var(--color-border-secondary)',
                         background: 'var(--color-background-primary)' }}
              >
                <option value="ambos">Produto + Projetos</option>
                <option value="produto">Produto</option>
                <option value="projetos">Projetos - Modelo Virtual</option>
              </select>
            </div>

            <button
              type="button"
              onClick={() => setFiltrosOpen(false)}
              style={{
                width: '100%', marginTop: 12, padding: '7px', borderRadius: 7,
                background: '#3a5c28', color: '#C8E6A0', border: 'none',
                fontSize: 13, fontWeight: 500, cursor: 'pointer'
              }}
            >
              Aplicar
            </button>
          </div>
        )}
      </div>

      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 14,
          marginBottom: '1rem',
          flexWrap: 'wrap',
          fontSize: 12,
          color: 'var(--color-text-secondary)'
        }}
      >
        <span style={{ fontWeight: 500, color: 'var(--color-text-primary)' }}>Progresso:</span>
        {[
          { cor: '#0F7A4A', label: '100% — Concluído' },
          { cor: '#5A9A1A', label: '≥75% — Quase lá' },
          { cor: '#C07800', label: '≥50% — Em andamento' },
          { cor: '#B01A1A', label: '<50% — Atrasado' },
          { cor: '#D3D1C7', label: '— Não iniciado' }
        ].map(({ cor, label }) => (
          <div key={label} style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
            <div style={{ width: 10, height: 10, borderRadius: 2, background: cor, flexShrink: 0 }} />
            {label}
          </div>
        ))}
      </div>

      {loading ? (
        <p>Carregando…</p>
      ) : casasAgrupadas.length === 0 ? (
        <p className="empty-state">
          Nenhuma casa cadastrada para as áreas Produto e Projetos - Modelo Virtual (ou ajuste o filtro de casa).
        </p>
      ) : (
        <div style={{ overflowX: 'auto', borderRadius: 8, border: '1px solid var(--color-border-tertiary)' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', tableLayout: 'fixed', minWidth: 400 }}>
            <colgroup>
              <col style={{ width: 180 }} />
              {casasVisiveis.map(cg => (
                <col key={cg.nome} style={{ width: 85 }} />
              ))}
            </colgroup>

            <thead>
              {/* Linha 1 — "Comportamento" e "Casas" (fundo explícito em cada th para vencer App.css `th { background: ... }`) */}
              <tr>
                <th
                  rowSpan={2}
                  style={{
                    background: '#243B26',
                    textAlign: 'left',
                    verticalAlign: 'middle',
                    padding: '8px 10px',
                    color: '#C8E6A0',
                    fontSize: 10,
                    fontWeight: 500,
                    textTransform: 'uppercase',
                    letterSpacing: '0.05em',
                    borderRight: '0.5px solid rgba(255,255,255,0.08)',
                    borderBottom: 'none'
                  }}
                >
                  Comportamento
                </th>
                <th
                  colSpan={Math.max(1, casasVisiveis.length)}
                  style={{
                    background: '#243B26',
                    textAlign: 'center',
                    padding: '8px 10px',
                    color: '#C8E6A0',
                    fontSize: 10,
                    fontWeight: 500,
                    textTransform: 'uppercase',
                    letterSpacing: '0.05em',
                    borderBottom: 'none'
                  }}
                >
                  Casas
                </th>
              </tr>

              {/* Linha 2 — nome de cada casa com bolinha colorida */}
              <tr>
                {casasVisiveis.map((casaGroup, idx) => {
                  const cor = getCorCasa(idx)
                  return (
                    <th
                      key={casaGroup.nome}
                      style={{
                        background: '#3A5528',
                        textAlign: 'center',
                        padding: '5px 4px',
                        color: '#C8E6A0',
                        fontSize: 9,
                        fontWeight: 500,
                        borderRight: '0.5px solid rgba(255,255,255,0.08)'
                      }}
                    >
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4 }}>
                        <div
                          style={{
                            width: 8,
                            height: 8,
                            borderRadius: 2,
                            background: cor.bg,
                            border: `1px solid ${cor.border}`,
                            flexShrink: 0
                          }}
                        />
                        {casaGroup.nome}
                      </div>
                    </th>
                  )
                })}
              </tr>
            </thead>

            <tbody>
              {areasOrdenadasExibicao.map(area => (
                <Fragment key={`area-${area.id}`}>
                  <tr>
                    <td
                      colSpan={casasVisiveis.length + 1}
                      style={{
                        background: '#1a2e1a',
                        color: '#C8E6A0',
                        fontSize: 11,
                        fontWeight: 500,
                        padding: '7px 10px',
                        textTransform: 'uppercase',
                        letterSpacing: '0.04em'
                      }}
                    >
                      {area.nome}
                    </td>
                  </tr>

                  {tarefasComGantt
                    .filter(t => t.area_id === area.id)
                    .map(tarefa => {
                      const totalAcoes = acoes.filter(a => a.tarefa_id === tarefa.id).length
                      return (
                        <tr
                          key={tarefa.id}
                          style={{
                            background: 'var(--color-background-primary)',
                            borderBottom: '0.5px solid var(--color-border-tertiary)'
                          }}
                        >
                          <td style={{ padding: '8px 10px' }}>
                            <div style={{ fontSize: 12, fontWeight: 500, color: 'var(--color-text-primary)' }}>
                              {tarefa.nome}
                            </div>
                            <div style={{ fontSize: 10, color: 'var(--color-text-secondary)', marginTop: 2 }}>
                              {totalAcoes} atividades
                            </div>
                          </td>
                          {casasVisiveis.map(casaGroup => {
                            const med = medirProgressoTarefaCasa(
                              tarefa.id,
                              casaGroup,
                              acoes,
                              dashData.cronograma,
                              dashData.ganttPlanejamento
                            )
                            const pct = med.pct
                            const cor = getCorProgresso(pct)
                            return (
                              <td
                                key={casaGroup.nome}
                                style={{ textAlign: 'center', padding: '6px 4px', verticalAlign: 'middle' }}
                              >
                                {pct === null ? (
                                  <span style={{ color: 'var(--color-text-secondary)', fontSize: 11 }}>—</span>
                                ) : (
                                  <div
                                    style={{
                                      display: 'flex',
                                      flexDirection: 'column',
                                      alignItems: 'center',
                                      gap: 3
                                    }}
                                  >
                                    <span style={{ fontSize: 12, fontWeight: 500, color: cor.text }}>{pct}%</span>
                                    <div
                                      style={{
                                        width: '100%',
                                        height: 4,
                                        background: 'var(--color-border-tertiary)',
                                        borderRadius: 2,
                                        overflow: 'hidden'
                                      }}
                                    >
                                      <div
                                        style={{
                                          width: `${pct}%`,
                                          height: '100%',
                                          background: cor.bar,
                                          borderRadius: 2
                                        }}
                                      />
                                    </div>
                                    <span style={{ fontSize: 8, color: 'var(--color-text-secondary)' }}>
                                      {med.concluidas}/{med.total} planej.
                                    </span>
                                  </div>
                                )}
                              </td>
                            )
                          })}
                        </tr>
                      )
                    })}
                </Fragment>
              ))}

              <tr style={{ background: '#F4F9EE', borderTop: '1px solid #8FBA6A' }}>
                <td
                  style={{
                    padding: '7px 10px',
                    fontWeight: 500,
                    fontSize: 12,
                    color: 'var(--color-text-primary)'
                  }}
                >
                  Total geral por casa
                </td>
                {casasVisiveis.map(casaGroup => {
                  let totalConcluidas = 0
                  for (const t of tarefasComGantt) {
                    const med = medirProgressoTarefaCasa(
                      t.id,
                      casaGroup,
                      acoes,
                      dashData.cronograma,
                      dashData.ganttPlanejamento
                    )
                    totalConcluidas += med.concluidas
                  }

                  const pctTotal =
                    totalAtividades > 0
                      ? Math.min(100, Math.round((totalConcluidas / totalAtividades) * 100))
                      : null
                  const cor = getCorProgresso(pctTotal)

                  return (
                    <td key={casaGroup.nome} style={{ textAlign: 'center', padding: '6px 4px' }}>
                      {pctTotal === null ? (
                        <span style={{ color: 'var(--color-text-secondary)', fontSize: 11 }}>—</span>
                      ) : (
                        <>
                          <div style={{ fontSize: 13, fontWeight: 500, color: cor.text }}>{pctTotal}%</div>
                          <div style={{ fontSize: 8, color: 'var(--color-text-secondary)' }}>
                            {totalConcluidas}/{totalAtividades} planej.
                          </div>
                        </>
                      )}
                    </td>
                  )
                })}
              </tr>
            </tbody>
          </table>
        </div>
      )}
    </>
  )
}
